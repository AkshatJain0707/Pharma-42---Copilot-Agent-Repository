# PLAYBOOK: Competitive War Gaming and Response Forecasting
Standalone knowledge file. Version 1.0, built 20 October 2026. Review every 90 days.

# PART A. CORE FORECASTING STANDARDS (built in, applies to every forecast)

## A1. Source tags and confidence
[P] primary: regulator document, registry, filing, statute, peer-reviewed paper. [S] secondary: trade press, analyst note, consultancy or law firm briefing. [U] unverified, user-supplied without source, or recalled. Confidence per conclusion: High (two or more independent primary sources agree), Medium (one primary, or primary plus consistent secondary), Low (secondary or unverified only, or sources conflict). Company press releases and investor decks are company-reported claims, not independent evidence.

## A2. A forecastable question
Event, date, resolution source. Weak: "Will the rival do well?" Strong: "Will the FDA approve X for indication Y by 30 June 2027, as shown on Drugs@FDA?" Rewrite vague questions and show the rewrite. No compound questions.

## A3. Base rate first, adjust in small named steps
Name the reference class. Find the base rate in a cited source (a retrieved or supplied source, or a dated figure in this playbook). State dataset, period, and definition of success. If none exists write "base rate needed". Adjust for case-specific evidence one named step at a time. Say how well the class fits and what differs. When two datasets disagree, show both and the effect on the answer.

## A4. Probability language
Give a range and a label, plus confidence in the basis. Labels: very unlikely under 10%, unlikely 10 to 30%, toss-up 30 to 70%, likely 70 to 90%, very likely over 90%. Never 0% or 100%. No false precision (no 37.4%). Probability (how likely) is separate from confidence (how good the evidence is).

## A5. Odds-form updating
odds = p / (1 - p). Posterior odds = prior odds x LR1 x LR2 x ... Posterior p = odds / (1 + odds). LR above 1 raises, below 1 lowers (use the reciprocal for opposing evidence). Judgement scale (a convention, not data): weak 1.5, moderate 2 to 3, strong 5, very strong 10. Count only independent evidence. Do not re-count what the reference class already reflects. If the posterior passes 95% or falls below 5%, widen the range. Arithmetic illustration only, not a base rate: prior 40% = odds 0.667; LR 2 = odds 1.333 = 57%.

## A6. Chains and combining
Chain probabilities (stage 1 x stage 2 x ...) only if stages are close to independent given the earlier stage; state the assumption. To combine several estimates of one event: convert to odds, take the (weighted) geometric mean, convert back, list the individual values, flag a spread above about 30 points, and explain the gap before relying on the aggregate.

## A7. Signposts, triggers, pre-mortem
Every forecast lists three to five signposts: an observable event, a source, whether it raises or lowers the estimate and how strongly, and a date or trigger. Add one decision trigger (if X by date, do Y). Run a pre-mortem: assume the forecast failed a year from now and list the three likeliest reasons and one cheap test.

## A8. Calibration
Log each forecast: ID, date, question, probability, resolution date. Brier score for a yes or no outcome = (p - outcome)^2; always saying 50% scores 0.25; lower is better. Under about 30 resolved forecasts, calibration statistics are indicative only. End every forecast with a one-line log entry.

## A9. Ethics and limits
Public information only. A probability about a listed company's event is an analytic judgement for strategy, not trading advice. No material non-public information. No coordination with competitors. No legal opinions. Follow competition law and the SCIP Code of Ethics.

## A10. Self-check before sending
Question resolvable? Base rate cited or "needed"? Every fact tagged? Range and label given? Signposts, trigger, pre-mortem, log line present? Any number from memory? Any horizon, currency, or unit mismatch? Anything that reads as advice or promotion? Fix before sending.

# PART B. DOMAIN KNOWLEDGE

## B1. Method references (concepts, no figures)
Analysis of competing hypotheses (Heuer, Psychology of Intelligence Analysis, 1999): list hypotheses, list evidence, judge each item against each hypothesis, favour the hypothesis with the least inconsistent evidence, and look for diagnostic evidence. Superforecasting practice (Tetlock and Gardner, 2015): decompose, use base rates, update in small steps, keep score. Game theory for strategy (Dixit and Nalebuff): players, moves, timing, information, payoffs; dominant and dominated moves; commitment and signalling.

## B2. Designing the game
- Players: client, each competitor, and deciding third parties (payers, regulators, partners, large buyers).
- Form: simultaneous (both commit without seeing the other) or sequential (one moves, the other responds). Pharma launches are often sequential with observable moves (filings, registry changes, price lists).
- Moves: launch timing, indication sequencing, price and contracting, partnering, lifecycle formulation, litigation, evidence generation, regional rights.
- Payoffs: choose one objective (value, share, time to peak, access position). Ordinal scores 1 to 5 are acceptable if stated. If the user supplies numbers, use them with units.
- Information: what each side can observe, with what lag. Signalling moves (guidance language) are cheap talk unless backed by commitments (spending, contracts, equity).

## B3. Public-source competitor profile
Priorities: annual report and investor materials (company-reported). Financial capacity: filings. Pipeline and timing: registries, regulator calendars; pipeline charts only as a cross-check. Deals: filed agreements and press releases (separate upfront from total potential value). Rights by region. Past responses to comparable events. Organisational signals: restructuring, leadership statements, hiring. Aliases: INN, code names, brand, licensee names, to avoid missing trials.

## B4. Reading company language
"Plan to" is weaker than "expect to", weaker than "on track to". A change in wording is a signal. Pipeline charts show phase, not timing. Guidance changes between quarters often tell more than the guidance. Risk-factor boilerplate is not a signal unless the text changed. A partner's milestone reporting can reveal progress the originator does not. Equity investment alongside a licence signals stronger commitment than a licence alone. A regional licence to a local company often means the originator will not build its own presence there.

## B5. Competing hypotheses worked example (illustrative placeholders)
Question: why did Rival R move its Phase 3 start back two quarters?
H1 enrolment trouble in the Phase 2 extension. H2 waiting for a competitor readout to choose the comparator. H3 supply or manufacturing issue. H4 strategic reprioritisation after a deal.
Evidence and scores (0 consistent or neutral, -1 inconsistent, -2 strongly inconsistent):
| Evidence | H1 | H2 | H3 | H4 |
|---|---|---|---|---|
| Registry start date moved twice | 0 | 0 | 0 | 0 |
| Phase 2 extension enrolment record unchanged | -2 | 0 | 0 | 0 |
| Earnings call cites "portfolio prioritisation" | 0 | 0 | -1 | 0 |
| No manufacturing disclosure or inspection finding | 0 | 0 | -1 | 0 |
| Competitor readout expected next quarter | 0 | 0 | 0 | 0 |
| Totals | -2 | 0 | -2 | 0 |
Evidence that fits every hypothesis (the registry change) does not discriminate. H2 and H4 lead on least inconsistency; next discriminating evidence: the next pipeline chart (which asset moved) and any new licensing deal. Estimated response probabilities then follow from the totals plus a base rate; show them as ranges that sum to 100%.

## B6. Payoff matrix method
Rows: client moves (include hold). Columns: rival responses (include do nothing). Cells: payoff on the stated objective. Expected payoff = sum over responses of probability x payoff. Worst case = row minimum. Regret = column best minus cell; maximum regret = row maximum of regret. Robust move: acceptable expected payoff with a worst case you can live with and low regret. Flag a dominated move (never better than another). Placeholder illustration: Move A payoffs against three responses (4, 3, 1); Move B (3, 3, 3). Probabilities 0.3, 0.4, 0.3: A = 1.2 + 1.2 + 0.3 = 2.7; B = 0.9 + 1.2 + 0.9 = 3.0. B has the higher expected payoff and the better worst case (3 versus 1).

## B7. Payers and partners as players
Biosimilar and generic markets show that payer channel decisions can dominate outcomes. In adalimumab, biosimilar share stayed under 2% in the first year and moved toward 23% by Nov 2024 after one large payer changed its formulary; private-label biosimilars later raised share (Medscape, Samsung Bioepis company-reported data, 2025 to 2026; VERIFY). Include the payer as a player with its own payoffs. Regulators and partners likewise.

## B8. Reference classes for response probabilities
Examples: rival response to a same-line launch; price or contracting response after a new entrant; deal response after a rival partnership; litigation response to a filing. Find a documented set of analogues (cases with dates and outcomes) in sources the user supplies or you retrieve. If none, write "base rate needed" and give wide qualitative ranges with the reason.

## B9. Signposts
Registry changes, hiring and site announcements, deal filings, price list changes, label submissions, earnings language shifts, congress abstracts, litigation filings, payer policy changes. Each with source, date, direction, strength.

## B10. Legal and ethical guardrails
No coordination with competitors on price, supply, or bids; competition law covers information exchange. No use of confidential competitor material or information a former employee brought. No misrepresentation of identity. If the user's plan depends on any of these, stop and suggest compliance.

## B11. Checklist before sending
Players and form stated; profile tagged and dated; capability test done; do-nothing included; matrix scores shown; probabilities sum to 100%; payoff arithmetic shown; robust move named; signposts dated; pre-mortem; log line; no confidential material.

## B12. Common failures
Assuming the rival acts as the client would. Ignoring do nothing. Ranking by most supporting evidence. Treating a press release as proof of intent. Using stale pipeline charts. Omitting the payer as a player.
