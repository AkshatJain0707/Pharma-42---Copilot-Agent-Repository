# PLAYBOOK: Loss of Exclusivity and Erosion Forecasting
Standalone knowledge file. Version 1.0, built 20 October 2026 from sources read that day. Review every 90 days. All statutory items and dates are VERIFY before client use. Not legal advice.

# PART A. CORE FORECASTING STANDARDS (built in, applies to every forecast)

## A1. Source tags and confidence
[P] primary: regulator document, registry, filing, statute, peer-reviewed paper. [S] secondary: trade press, analyst note, consultancy or law firm briefing. [U] unverified, user-supplied without source, or recalled. Confidence per conclusion: High (two or more independent primary sources agree), Medium (one primary, or primary plus consistent secondary), Low (secondary or unverified only, or sources conflict). Company press releases and investor decks are company-reported claims, not independent evidence.

## A2. A forecastable question
Event, date, resolution source. Weak: "Will the rival do well?" Strong: "Will the FDA approve X for indication Y by 30 June 2027, as shown on Drugs@FDA?" Rewrite vague questions and show the rewrite. No compound questions.

## A3. Base rate first, adjust in small named steps
Name the reference class. Find the base rate in a cited source (a retrieved or supplied source, or a dated figure in this playbook). State dataset, period, and definition of success. If none exists write "base rate needed". Adjust for case-specific evidence one named step at a time. Say how well the class fits and what differs. When two datasets disagree, show both and the effect on the answer.

## A4. Probability language
Give a range and a label, plus confidence in the basis. Labels: very unlikely under 10%, unlikely 10 to 30%, toss-up 30 to 70%, likely 70 to 90%, very likely over 90%. Never 0% or 100%. No false precision (no 37.4%). Probability (how likely) is separate from confidence (how good the evidence is).

## A5. Odds-form updating
odds = p / (1 - p). Posterior odds = prior odds x LR1 x LR2 x ... Posterior p = odds / (1 + odds). LR above 1 raises, below 1 lowers (use the reciprocal for opposing evidence). Judgement scale (a convention, not data): weak 1.5, moderate 2 to 3, strong 5, very strong 10. Count only independent evidence. Do not re-count what the reference class already reflects. If the posterior passes 95% or falls below 5%, widen the range. Arithmetic illustration only, not a base rate: prior 40% = odds 0.667; LR 2 = odds 1.333 = 57%.

## A6. Chains and combining
Chain probabilities (stage 1 x stage 2 x ...) only if stages are close to independent given the earlier stage; state the assumption. To combine several estimates of one event: convert to odds, take the (weighted) geometric mean, convert back, list the individual values, flag a spread above about 30 points, and explain the gap before relying on the aggregate.

## A7. Signposts, triggers, pre-mortem
Every forecast lists three to five signposts: an observable event, a source, whether it raises or lowers the estimate and how strongly, and a date or trigger. Add one decision trigger (if X by date, do Y). Run a pre-mortem: assume the forecast failed a year from now and list the three likeliest reasons and one cheap test.

## A8. Calibration
Log each forecast: ID, date, question, probability, resolution date. Brier score for a yes or no outcome = (p - outcome)^2; always saying 50% scores 0.25; lower is better. Under about 30 resolved forecasts, calibration statistics are indicative only. End every forecast with a one-line log entry.

## A9. Ethics and limits
Public information only. A probability about a listed company's event is an analytic judgement for strategy, not trading advice. No material non-public information. No coordination with competitors. No legal opinions. Follow competition law and the SCIP Code of Ethics.

## A10. Self-check before sending
Question resolvable? Base rate cited or "needed"? Every fact tagged? Range and label given? Signposts, trigger, pre-mortem, log line present? Any number from memory? Any horizon, currency, or unit mismatch? Anything that reads as advice or promotion? Fix before sending.

# PART B. DOMAIN KNOWLEDGE

## B1. Four dates (never merge)
1. Patent expiry, including extension. 2. Regulatory exclusivity end. 3. Earliest legal approval of a generic or biosimilar. 4. Actual market entry. Entry can precede patent expiry (settlement licence, at-risk launch) or follow it (approval delay, supply, litigation, payer pace).

## B2. US small molecules (structure; VERIFY each item in the statute and FDA pages)
- Listing: patents and exclusivities appear in the FDA Orange Book. Check listed patent claims and use codes.
- New chemical entity exclusivity: five years; a generic applicant can file after four years with a patent challenge (NCE-1).
- Three-year exclusivity for new clinical investigations supporting a change. Orphan exclusivity seven years. Paediatric exclusivity adds six months to existing protection.
- Patent term extension: up to five years, capped at 14 years of effective term after approval.
- Paragraph IV: a generic filer certifies a listed patent is invalid or not infringed. If the brand sues within 45 days, approval is stayed for up to 30 months unless a court rules earlier. First filers can earn 180-day exclusivity.
- Outcomes: court ruling, settlement with a licensed entry date, or at-risk launch. Authorised generics are brand-controlled entries that reduce first-filer value.

## B3. US biologics (structure; VERIFY)
- Reference product exclusivity: 12 years from first licensure; a biosimilar application cannot be filed until 4 years after.
- Patent resolution runs through the BPCIA information exchange ("patent dance") and litigation; track the Purple Book for licensure and exclusivity.
- Interchangeability designation affects pharmacy-level substitution. FDA policy on switching studies has been changing; check the current guidance.
- Uptake depends heavily on payer channel decisions (see B7).

## B4. European Union (read 20 Oct 2026; secondary legal summaries; VERIFY)
- Current rules: 8 years data protection plus 2 years market protection, with one extra year possible for a significant new indication.
- Reform: political agreement 11 Dec 2025; Council published final compromise texts on 6 Mar 2026; the Council formally adopted its first-reading position on 28 Sep 2026; European Parliament second-reading vote indicative for Nov 2026; not yet law at last check. New baseline: 8 years regulatory data protection plus 1 year market protection with conditional extensions, capped at 11 years (12 with a transferable exclusivity voucher for certain antimicrobials). Broader Bolar exemption lets generic and biosimilar firms prepare before expiry, so day-one launch is more plausible. Entry into force 20 days after publication; transposition generally 24 months; full applicability expected around 2028.
- Forecast rule: state which regime applies by marketing authorisation date and flag the adoption status as "verify".

## B5. Evidence on entry timing
- Settlements can license entry before patent expiry. Example: Teva's 10-Q for 2026 describes a settlement under which its aflibercept biosimilar partner can enter the US in Q4 2026 or earlier in some circumstances (company filing; verify the filing).
- Use dockets and filings for status. Treat company press statements as company-reported.
- Reference class for entry probability: past outcomes of comparable patent challenges (same modality, similar patent types, same court). If none is supplied write "base rate needed". Do not quote a litigation win rate from memory.

## B6. Evidence on price erosion (generic price versus pre-entry brand)
FDA CDER report (Dec 2019; generics first entering 2015 to 2017), average manufacturer price basis: with 1 generic producer the generic price was about 39% below the pre-entry brand price; 2 producers about 54% below; 4 producers about 79% below; 6 or more producers more than 95% below (invoice-price basis gives lower figures: about 31%, 44%, 73%, and more than 95%). This is generic price versus brand price, not brand volume loss. Use it for price-path logic: the number of entrants matters.
Arithmetic: generic price as a share of brand = 1 - discount. Two producers: 1 - 0.54 = 0.46.

## B7. Evidence on biosimilar uptake (US; company-reported market reports and secondary sources; read 20 Oct 2026; VERIFY)
- Adalimumab: nine biosimilars launched in 2023; under 2% of prescriptions in the first year; a PBM formulary change in Apr 2024 lifted biosimilar share to about 23% by Nov 2024; share stayed under about 20% outside the reference product into Feb 2025 per one analysis; Samsung Bioepis reported 60% biosimilar share as of Feb 2026 including a private-label biosimilar (company-reported).
- Ustekinumab: biosimilar share 27% at Q4 2025 and 42% at Q1 2026 (Samsung Bioepis, company-reported); average sales price of biosimilars reported down 73% quarter on quarter by Q2 2026.
- IQVIA commentary: erosion curves steepening for newer launches; mass switching followed when payers removed the originator from formularies or launched private-label products.
- Market size: 96 biosimilars approved across 21 molecules and 71 launched in the US as of June 2026 (Samsung Bioepis, company-reported).
Lesson: erosion speed is set by payer channel decisions, not entry date. Model a switch: parity access versus exclusion or private label.

## B8. Erosion modelling
- Revenue_t = baseline units_t x (1 - volume loss_t) x net price index_t x baseline net price.
- Volume loss path: logistic or step. Parameters: months to first big payer decision, share at 12 and 24 months after entry, final plateau. Use analogue data or write "analogue data needed". Do not quote a typical small-molecule erosion figure from memory.
- Net price index: reflects rebating to defend position, authorised generic, and policy effects.
- Scenario set: fast (exclusion or private-label switch within a year; many entrants), base, slow (parity access; one entrant; interchangeability absent). Always show cumulative revenue at risk over the horizon.
- Brand defences: lifecycle formulations, new indications, authorised generic, contracting. Treat intent as a hypothesis.

## B9. US price negotiation overlay (read 20 Oct 2026; CMS guidance and secondary summaries; VERIFY)
Selected drugs face a negotiated Medicare price from a set year. For initial price applicability year 2028 (selection announced 27 Jan 2026; negotiation period ends 31 Oct 2026), a drug can be removed when a generic or biosimilar is marketed; per CMS guidance, a determination made between 2 Nov 2026 and 31 Mar 2028 means the negotiated price applies for 2028 only and the drug ceases to be selected from 1 Jan 2029. Orphan exclusion was widened by 2025 legislation, with the 7- or 11-year clock for orphan-first drugs measured from approval of the first non-orphan indication. Always check whether a product is selected, eligible, or excluded.

## B10. Worked example (illustrative placeholders, not data)
Question: "Will a generic version of Product Z be marketed in the US before 1 Jan 2029?" Protection map: record read from Orange Book on date; core patent end [not verified]; challenge status [from docket]. Entry bands: before 1 Jan 2028, 1 Jan 2028 to 31 Dec 2028, after: probabilities 25%, 35%, 40% (sums to 100%; each needs evidence). Erosion (placeholder inputs): baseline 100 units, net price 1.00; fast scenario volume loss 70% at month 12 and 85% at month 24, price index 0.8; revenue year 1 after entry = 100 x 0.30 x 0.8 = 24 units of baseline revenue. State every parameter as an assumption with "analogue data needed".

## B11. Checklist before sending
Four dates separated; each date sourced or "not verified"; challenge status dated; statutory structure marked verify; scenarios sum to 100%; erosion analogue named with differences; channel switch modelled; policy overlay dated; signposts with sources; legal disclaimer; log line; no memory figures.

## B12. Common failures
Giving an expiry date from memory. Equating expiry with entry. Missing secondary patents. Using retail small-molecule erosion for an infused biologic. Forgetting authorised generics and private-label biosimilars. Ignoring that erosion speed depends on payer decisions. Treating a press release as a docket.
