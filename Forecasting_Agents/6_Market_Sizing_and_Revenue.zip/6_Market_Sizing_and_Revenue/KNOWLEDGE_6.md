# PLAYBOOK: Market Sizing and Revenue Forecasting
Standalone knowledge file. Version 1.0, built 20 October 2026. Review every 90 days. Source editions are VERIFY.

# PART A. CORE FORECASTING STANDARDS (built in, applies to every forecast)

## A1. Source tags and confidence
[P] primary: regulator document, registry, filing, statute, peer-reviewed paper. [S] secondary: trade press, analyst note, consultancy or law firm briefing. [U] unverified, user-supplied without source, or recalled. Confidence per conclusion: High (two or more independent primary sources agree), Medium (one primary, or primary plus consistent secondary), Low (secondary or unverified only, or sources conflict). Company press releases and investor decks are company-reported claims, not independent evidence.

## A2. A forecastable question
Event, date, resolution source. Weak: "Will the rival do well?" Strong: "Will the FDA approve X for indication Y by 30 June 2027, as shown on Drugs@FDA?" Rewrite vague questions and show the rewrite. No compound questions.

## A3. Base rate first, adjust in small named steps
Name the reference class. Find the base rate in a cited source (a retrieved or supplied source, or a dated figure in this playbook). State dataset, period, and definition of success. If none exists write "base rate needed". Adjust for case-specific evidence one named step at a time. Say how well the class fits and what differs. When two datasets disagree, show both and the effect on the answer.

## A4. Probability language
Give a range and a label, plus confidence in the basis. Labels: very unlikely under 10%, unlikely 10 to 30%, toss-up 30 to 70%, likely 70 to 90%, very likely over 90%. Never 0% or 100%. No false precision (no 37.4%). Probability (how likely) is separate from confidence (how good the evidence is).

## A5. Odds-form updating
odds = p / (1 - p). Posterior odds = prior odds x LR1 x LR2 x ... Posterior p = odds / (1 + odds). LR above 1 raises, below 1 lowers (use the reciprocal for opposing evidence). Judgement scale (a convention, not data): weak 1.5, moderate 2 to 3, strong 5, very strong 10. Count only independent evidence. Do not re-count what the reference class already reflects. If the posterior passes 95% or falls below 5%, widen the range. Arithmetic illustration only, not a base rate: prior 40% = odds 0.667; LR 2 = odds 1.333 = 57%.

## A6. Chains and combining
Chain probabilities (stage 1 x stage 2 x ...) only if stages are close to independent given the earlier stage; state the assumption. To combine several estimates of one event: convert to odds, take the (weighted) geometric mean, convert back, list the individual values, flag a spread above about 30 points, and explain the gap before relying on the aggregate.

## A7. Signposts, triggers, pre-mortem
Every forecast lists three to five signposts: an observable event, a source, whether it raises or lowers the estimate and how strongly, and a date or trigger. Add one decision trigger (if X by date, do Y). Run a pre-mortem: assume the forecast failed a year from now and list the three likeliest reasons and one cheap test.

## A8. Calibration
Log each forecast: ID, date, question, probability, resolution date. Brier score for a yes or no outcome = (p - outcome)^2; always saying 50% scores 0.25; lower is better. Under about 30 resolved forecasts, calibration statistics are indicative only. End every forecast with a one-line log entry.

## A9. Ethics and limits
Public information only. A probability about a listed company's event is an analytic judgement for strategy, not trading advice. No material non-public information. No coordination with competitors. No legal opinions. Follow competition law and the SCIP Code of Ethics.

## A10. Self-check before sending
Question resolvable? Base rate cited or "needed"? Every fact tagged? Range and label given? Signposts, trigger, pre-mortem, log line present? Any number from memory? Any horizon, currency, or unit mismatch? Anything that reads as advice or promotion? Fix before sending.

# PART B. DOMAIN KNOWLEDGE

## B1. Decision first
Write the key question in one sentence with a decision attached (for example: "Is second-line demand in country X large enough to justify a local launch?"). The decision sets the precision needed. Use at least two methods when the estimate drives a large decision.

## B2. Method choice
| Method | Use when | Weakness |
|---|---|---|
| Epidemiology funnel (bottom-up) | New indication with a defined eligible population | Every stage needs a source |
| Share of existing spend or volume | Established market with a new entrant | Share logic is a judgement |
| Analogue uptake | Few direct data; comparable launches exist | Analogue fit is a judgement |
| Top-down check | Sanity check for any method | Too coarse alone |

## B3. Funnel template and formulas
Population, then: disease incidence or prevalence, diagnosed, eligible by stage or biomarker, eligible by line of therapy, treated (access and clinical fit), addressable after contraindications. Then: share, patients on product, average fraction of year on therapy, patient-years, net price per patient-year, revenue.
- Patients at stage n = patients at stage n-1 x rate at stage n.
- Patients on product = addressable treated x share.
- Patient-years = patients on product x average fraction of year on therapy.
- Revenue = patient-years x net price per patient-year.
Placeholder arithmetic (illustrative, not data): 10,000 incident cases x 80% diagnosed = 8,000; x 30% biomarker-eligible = 2,400; x 50% receiving the target line = 1,200; x 70% treated = 840; x 25% peak share = 210 patients; x 0.75 fraction of year = 157.5 patient-years; x 60,000 net price per patient-year = 9,450,000.

## B4. Source order for inputs (editions and access are VERIFY)
| Input | Sources, best first |
|---|---|
| Cancer incidence, prevalence, mortality | National cancer registry; the IARC GLOBOCAN database; SEER (US); European cancer information system; peer-reviewed registry papers |
| Other disease burden | Global Burden of Disease estimates; national surveys; published epidemiology; claims-based studies |
| Biomarker prevalence | Peer-reviewed frequency studies; large registries; trial screening data; label |
| Diagnosis and treatment rates; line attrition | Guidelines; real-world cohort studies; registry data; trial patient flow; physician survey (flag as survey) |
| Price | Regulator or payer price lists; US CMS average sales price and NADAC files; national price databases; net price needs rebate evidence, otherwise "net price not disclosed" |
| Analogue launches | Company filings (sales by quarter), regulator approval dates, published launch analyses |
Paid databases are user-supplied: tag [U] unless the user gives source and date.

## B5. Uptake curves
Logistic share: share(t) = peak / (1 + exp(-k x (t - t_half))), t in years from launch, t_half = time to half of peak, k = steepness per year. Placeholder illustration: peak 25%, t_half 2 years, k 1.5 per year: share(1) = 25 / (1 + e^1.5) = 25 / 5.4817 = 4.56%; share(2) = 12.5%; share(3) = 25 / (1 + e^-1.5) = 25 / 1.2231 = 20.44%.
Bass diffusion: cumulative adoption fraction F(t) = (1 - e^(-(p+q)t)) / (1 + (q/p) x e^(-(p+q)t)), p = innovation coefficient, q = imitation coefficient. Placeholder illustration: p 0.03, q 0.38, t 5: F = (1 - e^-2.05) / (1 + 12.667 x e^-2.05) = 0.8713 / 2.6306 = 0.331. The coefficients come from analogues or are stated assumptions, never typical values from memory.
Analogue method: choose launches by line of therapy, diagnostic need, access barrier, competition, modality, and channel. Scale the shape, not the level. State what differs.
Evidence that uptake depends on payer channel: in US adalimumab, biosimilar share was under 2% of prescriptions in the first year and rose to about 23% by Nov 2024 after one large payer changed its formulary, and reached 60% by Feb 2026 including private-label biosimilars (Medscape, Samsung Bioepis company-reported, 2025 to 2026; VERIFY). Treat payer channel decisions as a driver of time to peak.

## B6. Persistence, compliance, patient-years
Average fraction of year on therapy depends on persistence, discontinuation, treatment duration, and dosing schedule. For fixed-duration therapies compute treated courses and price per course instead. State which basis you use.

## B7. Price and protection cap
Net price per patient-year in a stated currency and price year, by channel: blended net = sum of (channel share x channel net price). Cap the horizon at the assumed end of exclusivity or apply an erosion assumption with named analogue; state the assumption and mark "verify current status" for protection dates. Policy can change net price before expiry; name the policy and date if used.

## B8. Ranges, scenarios, sensitivity
All-low and all-high combinations give a very wide bound that is unlikely to occur because inputs are rarely all extreme together. One-at-a-time sensitivity: move each input to low and high with others at base.
Placeholder illustration: patients 1,000 / 2,000 / 3,500; share 0.10 / 0.20 / 0.35; net price 20,000 / 30,000 / 40,000; fraction of year 0.60 / 0.80 / 0.95. Base revenue = 2,000 x 0.20 x 30,000 x 0.80 = 9,600,000. All-low = 1,000 x 0.10 x 20,000 x 0.60 = 1,200,000. All-high = 3,500 x 0.35 x 40,000 x 0.95 = 46,550,000. Swings at base: patients 4,800,000 to 16,800,000 (swing 12.0M); share 4,800,000 to 16,800,000 (12.0M); price 6,400,000 to 12,800,000 (6.4M); fraction of year 7,200,000 to 11,400,000 (4.2M). Ranking: patients and share tie, then price, then fraction of year. Where the bottom-up share is a judgement, the swing factor is the assumption to test first.
Scenarios: low, base, high, naming the drivers that differ (label breadth, access, competitor entry, diagnostic adoption). Do not vary all inputs at once.

## B9. Triangulation and sanity checks
Revenue per treated patient versus analogue products. Implied share of total treated segment. Bottom-up above the whole segment is an error until explained. Compare peak patients with the capacity of diagnosis and treatment sites. Check units and years across all stages. Compare time to peak with the analogue.

## B10. Simulation note
Triangular distributions (low, most likely, high) are a transparent default and encode judgement. Independent sampling understates spread if inputs are correlated (for example share and price). If a simulation is run elsewhere, report mean, P10, P50, P90, and the share of trials above the decision threshold. Do not claim to have simulated if you have not.

## B11. Output hygiene
Currency and price year. Gross or net. Peak defined (peak year, peak sales, or average over a window). Rounding at the end. One assumption log. Units on every number.

## B12. Checklist before sending
Decision named; one of incidence or prevalence; every stage sourced or "input needed"; units consistent; formulas and arithmetic shown; uptake method named with analogue differences; patient-years separate from patients; net price basis stated; protection cap stated; sensitivity ranked; triangulated; scenarios name drivers; pre-mortem; log line; no number from memory.

## B13. Common failures
Mixing incidence and prevalence. Forgetting line-of-therapy attrition. Applying biomarker prevalence from another population. Ignoring persistence. Using list price as net price. Applying peak share in year one. Ignoring the end of exclusivity. Presenting a single number with no range.
