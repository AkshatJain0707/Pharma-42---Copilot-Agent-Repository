# PLAYBOOK: Probability of Success and Catalyst Forecasting
Standalone knowledge file. Version 1.0, built 20 October 2026 from sources read that day. Review every 90 days. Items marked VERIFY change often.

# PART A. CORE FORECASTING STANDARDS (built in, applies to every forecast)

## A1. Source tags and confidence
[P] primary: regulator document, registry, filing, statute, peer-reviewed paper. [S] secondary: trade press, analyst note, consultancy or law firm briefing. [U] unverified, user-supplied without source, or recalled. Confidence per conclusion: High (two or more independent primary sources agree), Medium (one primary, or primary plus consistent secondary), Low (secondary or unverified only, or sources conflict). Company press releases and investor decks are company-reported claims, not independent evidence.

## A2. A forecastable question
Event, date, resolution source. Weak: "Will the rival do well?" Strong: "Will the FDA approve X for indication Y by 30 June 2027, as shown on Drugs@FDA?" Rewrite vague questions and show the rewrite. No compound questions.

## A3. Base rate first, adjust in small named steps
Name the reference class. Find the base rate in a cited source (a retrieved or supplied source, or a dated figure in this playbook). State dataset, period, and definition of success. If none exists write "base rate needed". Adjust for case-specific evidence one named step at a time. Say how well the class fits and what differs. When two datasets disagree, show both and the effect on the answer.

## A4. Probability language
Give a range and a label, plus confidence in the basis. Labels: very unlikely under 10%, unlikely 10 to 30%, toss-up 30 to 70%, likely 70 to 90%, very likely over 90%. Never 0% or 100%. No false precision (no 37.4%). Probability (how likely) is separate from confidence (how good the evidence is).

## A5. Odds-form updating
odds = p / (1 - p). Posterior odds = prior odds x LR1 x LR2 x ... Posterior p = odds / (1 + odds). LR above 1 raises, below 1 lowers (use the reciprocal for opposing evidence). Judgement scale (a convention, not data): weak 1.5, moderate 2 to 3, strong 5, very strong 10. Count only independent evidence. Do not re-count what the reference class already reflects. If the posterior passes 95% or falls below 5%, widen the range. Arithmetic illustration only, not a base rate: prior 40% = odds 0.667; LR 2 = odds 1.333 = 57%.

## A6. Chains and combining
Chain probabilities (stage 1 x stage 2 x ...) only if stages are close to independent given the earlier stage; state the assumption. To combine several estimates of one event: convert to odds, take the (weighted) geometric mean, convert back, list the individual values, flag a spread above about 30 points, and explain the gap before relying on the aggregate.

## A7. Signposts, triggers, pre-mortem
Every forecast lists three to five signposts: an observable event, a source, whether it raises or lowers the estimate and how strongly, and a date or trigger. Add one decision trigger (if X by date, do Y). Run a pre-mortem: assume the forecast failed a year from now and list the three likeliest reasons and one cheap test.

## A8. Calibration
Log each forecast: ID, date, question, probability, resolution date. Brier score for a yes or no outcome = (p - outcome)^2; always saying 50% scores 0.25; lower is better. Under about 30 resolved forecasts, calibration statistics are indicative only. End every forecast with a one-line log entry.

## A9. Ethics and limits
Public information only. A probability about a listed company's event is an analytic judgement for strategy, not trading advice. No material non-public information. No coordination with competitors. No legal opinions. Follow competition law and the SCIP Code of Ethics.

## A10. Self-check before sending
Question resolvable? Base rate cited or "needed"? Every fact tagged? Range and label given? Signposts, trigger, pre-mortem, log line present? Any number from memory? Any horizon, currency, or unit mismatch? Anything that reads as advice or promotion? Fix before sending.

# PART B. DOMAIN KNOWLEDGE

## B1. Event chain
Phase transition (success defined by the dataset), pivotal readout (primary endpoint met, as pre-specified), filing acceptance, approval, label breadth, launch timing, reimbursement. Each link has its own reference class. A question about "reaching market" is a product of links, not one number.

## B2. Dated benchmark tables (secondary sources; read 20 Oct 2026; verify newer editions)
| Dataset | Period | What it reports | Source |
|---|---|---|---|
| BIO, Informa Pharma Intelligence, QLS Advisors, "Clinical Development Success Rates and Contributing Factors 2011-2020" | 2011 to 2020, 9,704 programs, 12,728 phase transitions | Likelihood of approval (LOA) from Phase I, all programs: 7.9% (9.6% in the 2006 to 2015 report). Phase II to III transition: 28.9%, the largest hurdle. Average 10.5 years from Phase I to approval | BIO report, published Feb 2021 |
| Same report, by area | 2011 to 2020 | Hematology LOA 23.9% (highest of 14 areas); urology 3.6% (lowest); oncology 5.3%; immuno-oncology 12.4% | BIO report |
| Same report, by design | 2011 to 2020 | Programs using patient-selection biomarkers: LOA 15.9%. Biologics 9.1% vs new molecular entities 5.7%. Vaccines 9.7% | BIO report, via CPHI summary |
| Citeline (Biomedtracker), "Why Are Clinical Development Success Rates Falling?" | 2014 to 2023 | LOA from Phase I 6.7%. Phase I 47%, Phase II 28%, Phase III 55% | Citeline and Norstella, 2024 |
| Derived (arithmetic on Citeline figures) | 2014 to 2023 | Implied NDA/BLA stage success = 0.067 / (0.47 x 0.28 x 0.55) = about 92.6%. A derived figure, not published | Calculated here |
| Comparison of providers | varies | One review reports LOA of 7.9% (BIO) against 13.2% (IQVIA) for all therapies | Nature Reviews Drug Discovery article, 2025 (verify) |
Why datasets disagree: different program counts and periods, treatment of Phase I/II hybrids, definition of success (phase completion vs next-phase entry), inclusion of indications versus programs, and company size mix. Always state which you used. Use sensitivity: run the estimate on both datasets and report the spread.
Chain arithmetic check (Citeline stages): 0.47 x 0.28 x 0.55 x 0.926 = 0.067, which reproduces 6.7%.
Therapy area, modality, and biomarker selection move the class far more than most case-specific evidence. Choose the class first.

## B3. Case-specific evidence and judgement likelihood ratios
A convention, not data: weak 1.5, moderate 2 to 3, strong 5, very strong 10, reciprocals for evidence against.
| Evidence | Direction | Typical strength |
|---|---|---|
| Human genetic or clinical validation of the target | Raises | Moderate to strong |
| Earlier-phase effect large, consistent, in the target population | Raises | Moderate |
| Same endpoint and population in the earlier trial | Raises | Moderate |
| Different endpoint or broader population than the earlier trial | Lowers | Moderate |
| Surrogate endpoint with weak link to outcomes | Lowers | Weak to moderate |
| Open-label, small, or subgroup-driven earlier result | Lowers | Moderate |
| Regulator agreement on design (published guidance, designation, special protocol) | Raises | Weak to moderate |
| Sponsor with approvals in class | Raises | Weak |
| Competitor in class failed on the same mechanism | Lowers | Moderate to strong |
| Crowded class with a strong standard of care (high placebo or comparator bar) | Lowers | Weak to moderate |
Rule: if the case belongs in a narrower dataset class, use that class and count only residual evidence.

## B4. FDA review clock arithmetic (PDUFA VII, FY2023 to 2027; PDUFA VIII letter keeps the same cohort goals from 1 Oct 2027; read at fda.gov, 20 Oct 2026)
- NME NDAs and original BLAs: FDA aims to act on 90% within 10 months of the 60-day filing date (standard) or 6 months of the 60-day filing date (priority). That is about 12 and 8 months from submission.
- Non-NME original NDAs: 10 months (standard) or 6 months (priority) from receipt.
- Resubmission after a complete response: Class 1, 2 months; Class 2, 6 months, from receipt.
- A major amendment during review can extend the goal date by 3 months.
- FDA says it will communicate review issues about 8 weeks (standard) or 6 weeks (priority) before the goal date.
- Worked example: submission 2 Jan 2027, NME, standard: filing date 3 Mar 2027 (2 Jan plus 60 days), goal about 3 Jan 2028. Priority: about 3 Sep 2027. Confirm the exact goal date from the company or FDA letter.
- A goal date is a performance commitment for 90% of applications, not a guaranteed decision date. FDA can act early or extend.
- Example of first-cycle outcomes: FDA testimony reported 52 of 60 NME and original BLA applications acted on in FY2021 were first-cycle approvals (about 87%). That is a different measure from success from Phase I and describes filed applications.

## B5. Complete response letters: what the evidence says (read 20 Oct 2026; secondary aggregators unless noted; VERIFY with the openFDA database)
- FDA began publishing CRLs on openFDA in July 2025 (200+ letters for applications from 2020 to 2024 that were later approved), added 89 unapproved-application letters in Sep 2025, reached about 459 records by 13 Aug 2026, paused real-time publication in Apr 2026 and resumed on 10 Jul 2026 (ph3.bio, secondary). The set is growing and not complete. The first tranche is biased toward products later approved.
- Johns Hopkins study of 43 novel therapeutics with CRLs later approved (2020 to 2024): deficiencies cited in facilities 65%, CMC 51%, labeling 44%, efficacy 26%, safety 26%, pharmacology 14%; median 1.28 years from CRL to approval.
- McCarthy and O'Boyle 2026, as summarised by ph3.bio: among NDAs with a CRL, about 64% were later approved; 75% when CMC was cited versus 44% when safety was cited; CMC the most common primary category (about 45%); about 709 days extra versus first-cycle approval.
- RSM US (Feb 2026), first 200+ letters: mean about 2.4 to 2.5 years from CRL to approval; manufacturing-primary median over 21 months.
- ph3.bio: 62.6% (286 of 457) of published letters had a manufacturing or quality section.
Use: classify main risk. Efficacy or safety CRL: low recovery, long delay. CMC or facility CRL: higher recovery, still a long delay, often tied to inspection timing. Treat the above as a reference class for "what happens after a CRL", not as a base rate for approval.

## B6. Catalyst calendar rules
| Date confidence | Meaning |
|---|---|
| High | Regulator goal date, scheduled advisory committee or congress with fixed date |
| Medium | Company guidance naming a quarter or month, consistent with registry |
| Low | Vague guidance ("mid-year", "2H"), history of slippage, event-driven |
Registry primary completion date is not the date results appear. Results for applicable trials are due on ClinicalTrials.gov within a statutory window after primary completion (VERIFY the current rule); sponsors often announce topline first. Read registry histories for date changes and record the date you read. Give probability by date band: for example by end of quarter 1, 2, 3, with slippage history as the evidence.

## B7. Update library (judgement ratios, not data)
| New event | Usual direction | Typical LR |
|---|---|---|
| Interim analysis passed without stopping for futility | Raises | 1.5 to 2 |
| Trial stopped early for efficacy | Raises | 5 to 10 |
| Trial stopped for futility | Lowers | 0.1 to 0.2 |
| Primary completion date pushed back twice | Lowers (timing) | 1.5 on delay |
| Advisory committee scheduled, briefing documents balanced | Neutral to weak | 1 to 1.5 |
| Briefing documents raise efficacy concerns | Lowers | 0.3 to 0.5 |
| Pre-approval inspection with findings | Lowers (timing and approval) | 0.5 to 0.7 |
| Late-cycle meeting reported as "no major issues" (company-reported) | Raises | 1.2 to 1.5 |
| Competitor in class reads out negative on same mechanism | Lowers | 0.4 to 0.6 |

## B8. Worked example (illustrative placeholders, not data)
Question: "Will Asset X meet its primary endpoint in the Phase 3 trial NCTxxxxxxxx, with topline announced by 31 Dec 2027?"
Class (illustrative): Phase 3 to filing stage, Citeline 2014 to 2023: 55%. Evidence: Phase 2 effect large and on the same endpoint (LR 2), open-label Phase 2 (LR 0.67), regulator-agreed design (LR 1.3). Prior odds 0.55 / 0.45 = 1.222. Product of ratios 2 x 0.67 x 1.3 = 1.742. Posterior odds 2.129. Posterior p = 2.129 / 3.129 = 68%. Range 55% to 75%, label toss-up to likely, confidence in basis Medium. Timing: topline by 31 Dec 2027 depends on date confidence; give bands. State that every ratio is a judgement.

## B9. Checklist before sending
Question resolvable and dated; class and dataset stated; dated benchmark cited; evidence independent; arithmetic shown; range and label; timing bands; signposts with sources; decision trigger; pre-mortem; log line; no number from memory; no advice; draft label; one follow-up question.

## B10. Common failures
All-phase base rate used for a specific phase. Ignoring biomarker selection. Treating company timing as fixed. Counting the same evidence twice. Reporting a goal date as a decision date. Using the first CRL tranche as the base rate for approval. Giving a probability with no resolution source.
