# PLAYBOOK: Net Price, Access, and Price-Policy Forecasting
Standalone knowledge file. Version 1.0, built 20 October 2026 from sources read that day. Review every 90 days. Policy changes fast: every item is VERIFY before client use.

# PART A. CORE FORECASTING STANDARDS (built in, applies to every forecast)

## A1. Source tags and confidence
[P] primary: regulator document, registry, filing, statute, peer-reviewed paper. [S] secondary: trade press, analyst note, consultancy or law firm briefing. [U] unverified, user-supplied without source, or recalled. Confidence per conclusion: High (two or more independent primary sources agree), Medium (one primary, or primary plus consistent secondary), Low (secondary or unverified only, or sources conflict). Company press releases and investor decks are company-reported claims, not independent evidence.

## A2. A forecastable question
Event, date, resolution source. Weak: "Will the rival do well?" Strong: "Will the FDA approve X for indication Y by 30 June 2027, as shown on Drugs@FDA?" Rewrite vague questions and show the rewrite. No compound questions.

## A3. Base rate first, adjust in small named steps
Name the reference class. Find the base rate in a cited source (a retrieved or supplied source, or a dated figure in this playbook). State dataset, period, and definition of success. If none exists write "base rate needed". Adjust for case-specific evidence one named step at a time. Say how well the class fits and what differs. When two datasets disagree, show both and the effect on the answer.

## A4. Probability language
Give a range and a label, plus confidence in the basis. Labels: very unlikely under 10%, unlikely 10 to 30%, toss-up 30 to 70%, likely 70 to 90%, very likely over 90%. Never 0% or 100%. No false precision (no 37.4%). Probability (how likely) is separate from confidence (how good the evidence is).

## A5. Odds-form updating
odds = p / (1 - p). Posterior odds = prior odds x LR1 x LR2 x ... Posterior p = odds / (1 + odds). LR above 1 raises, below 1 lowers (use the reciprocal for opposing evidence). Judgement scale (a convention, not data): weak 1.5, moderate 2 to 3, strong 5, very strong 10. Count only independent evidence. Do not re-count what the reference class already reflects. If the posterior passes 95% or falls below 5%, widen the range. Arithmetic illustration only, not a base rate: prior 40% = odds 0.667; LR 2 = odds 1.333 = 57%.

## A6. Chains and combining
Chain probabilities (stage 1 x stage 2 x ...) only if stages are close to independent given the earlier stage; state the assumption. To combine several estimates of one event: convert to odds, take the (weighted) geometric mean, convert back, list the individual values, flag a spread above about 30 points, and explain the gap before relying on the aggregate.

## A7. Signposts, triggers, pre-mortem
Every forecast lists three to five signposts: an observable event, a source, whether it raises or lowers the estimate and how strongly, and a date or trigger. Add one decision trigger (if X by date, do Y). Run a pre-mortem: assume the forecast failed a year from now and list the three likeliest reasons and one cheap test.

## A8. Calibration
Log each forecast: ID, date, question, probability, resolution date. Brier score for a yes or no outcome = (p - outcome)^2; always saying 50% scores 0.25; lower is better. Under about 30 resolved forecasts, calibration statistics are indicative only. End every forecast with a one-line log entry.

## A9. Ethics and limits
Public information only. A probability about a listed company's event is an analytic judgement for strategy, not trading advice. No material non-public information. No coordination with competitors. No legal opinions. Follow competition law and the SCIP Code of Ethics.

## A10. Self-check before sending
Question resolvable? Base rate cited or "needed"? Every fact tagged? Range and label given? Signposts, trigger, pre-mortem, log line present? Any number from memory? Any horizon, currency, or unit mismatch? Anything that reads as advice or promotion? Fix before sending.

# PART B. DOMAIN KNOWLEDGE

## B1. Terms
List price (wholesale acquisition cost in the US), gross price, net price after rebates, discounts, and fees, price per pack or per patient-year, out-of-pocket cost, formulary tier, utilisation management (prior authorisation, step therapy, quantity limits), private-label channel.

## B2. Waterfall template
List price, less statutory rebates and discounts (Medicaid, public-sector programmes, mandatory discounts in a market), less commercial rebates to payers and pharmacy benefit managers, less distribution and service fees, equals net. Many figures are not public. Use public proxies only where they exist, label them, and keep ranges wide. Net by channel: commercial, Medicare Part D, Medicare Part B, Medicaid, public programmes, hospital, cash or direct-to-consumer. Blended net = sum of channel share x channel net price. Check that channel shares sum to 100%.
Structure to verify before use: Medicaid rebates (basic percentage of average manufacturer price plus an inflation-linked penalty, and best-price rules); 340B discounts; the Part D redesign from 2025 (annual out-of-pocket cap for beneficiaries and a manufacturer discount programme replacing the coverage gap discount; verify percentages and indexed cap).

## B3. US Medicare negotiation programme (CMS guidance and secondary summaries read 20 Oct 2026; VERIFY)
| Cycle | Initial price applicability year | Drugs | Status |
|---|---|---|---|
| 1 | 2026 | 10 Part D drugs | Negotiated prices effective 1 Jan 2026 |
| 2 | 2027 | 15 Part D drugs | Prices published Nov 2025; effective 1 Jan 2027 |
| 3 | 2028 | 15 drugs, first cycle including Part B, plus one selected for renegotiation | Selection announced 27 Jan 2026; written agreements by 28 Feb 2026; CMS initial offer by 1 Jun 2026; final written offer by 30 Sep 2026; negotiation period ends 31 Oct 2026; prices apply from 1 Jan 2028 |
- Eligibility structure (verify in statute and guidance): high Medicare spend; single source; time since approval or licensure of at least 7 years (small molecules) or 11 years (biologics) at selection; no marketed generic or biosimilar; exclusions for orphan-designated drugs under defined conditions, low-spend drugs, plasma-derived products; a temporary small biotech exception.
- Orphan exclusion was widened by 2025 legislation: drugs with an orphan designation and only orphan indications are excluded, and the 7- or 11-year clock runs from approval of the first non-orphan indication (Milliman analysis, Jan 2026). The widened rule first applies to IPAY 2028.
- A drug leaves the programme when a generic or biosimilar is marketed. CMS guidance: a determination made between 2 Nov 2026 and 31 Mar 2028 means the negotiated price applies for 2028 only; the drug ceases to be selected from 1 Jan 2029.
- CMS has said earlier negotiated prices can inform offers for therapeutic alternatives in later cycles.
- Forecast use: model a selection event as a probability by cycle using eligibility screens and spend rank evidence; model the effect as a step change in Medicare net price from the effective year, scaled by Medicare channel share.

## B4. Most-favored-nation agreements and TrumpRx (secondary sources; White House fact sheets primary; read 20 Oct 2026; VERIFY)
- Executive order 14297 signed 12 May 2025 directed work on most-favored-nation pricing. First company agreement: Pfizer, 30 Sep 2025. By 31 Aug 2026 nine more companies were announced (total 26 manufacturers, about 89% of the branded market per the White House). A White House fact sheet of 18 Sep 2026 extended MFN-aligned pricing to all 50 state Medicaid programs.
- Reported commitments (company and press accounts): MFN-aligned prices in Medicaid, MFN-aligned launch pricing for new drugs, direct-to-consumer cash prices through the TrumpRx.gov site (launched Feb 2026), and US investment pledges. Terms are not public. These are voluntary agreements, not statutes, and could change.
- Estimates differ: a JAMA research letter (July 2026) estimated about USD 8.6 billion a year of Medicaid savings from the first 17 companies' policies; Health Affairs and NPR commentary say effects on most patients' prices are limited and terms opaque.
- A CMS proposed rule on MFN-type pricing in Medicare Part B was reported at the White House budget office; status not verified.
- Forecast use: treat as (1) Medicaid net price pressure, (2) launch price parity and ex-US launch sequencing risk (reference-pricing research shows firms may delay launches in lower-income markets to avoid referencing), (3) cash-channel price transparency. Use scenarios, not point estimates; say terms are not public.

## B5. Ex-US
External reference pricing links prices across markets. HTA bodies set evidence and value expectations; several link outcomes to pricing and reimbursement. EU joint clinical assessment: from 12 Jan 2025 for new oncology active substances and advanced therapies; orphan medicines from Jan 2028; all centrally authorised medicines from 2030 (VERIFY). JCA affects evidence, not price directly; check how each member state uses it. EU pharmaceutical reform (data protection and market protection changes): political agreement 11 Dec 2025; Council adopted its first-reading position on 28 Sep 2026; Parliament vote pending; not yet law at last check (VERIFY).

## B6. Access mechanics and payer channel evidence
Payers weigh clinical benefit, comparators, budget impact, and available alternatives. Tighter access follows many comparable options, high budget impact, weak comparative data, and available biosimilars or generics. Looser access follows unmet need, strong comparative data, outcomes or volume agreements, and guideline endorsement. Channel decisions dominate: in adalimumab, biosimilar share stayed under 2% in the first year after launch and rose to about 23% by Nov 2024 after a large PBM changed its formulary; private-label biosimilars drove much of the later share (Medscape, Samsung Bioepis, company-reported; JMCP 2025). In ustekinumab, biosimilar share reached 27% by Q4 2025 and 42% by Q1 2026 (company-reported). Model a payer-channel switch as a named scenario driver with a date.

## B7. Forecasting a policy event (method)
1. Question with date and resolution source (for example: "Will Product P be on the CMS selected drug list for IPAY 2029, as published by CMS?").
2. Eligibility screen from statute and guidance (yes, no, unclear).
3. Reference class: past selection cycles for drugs passing the screen with similar spend rank; cite a retrieved list or write "base rate needed".
4. Adjust: spend trend, exclusion risk, generic or biosimilar entry timing, legislative changes.
5. Range, label, confidence, signposts (guidance releases, spend data files, litigation outcomes), trigger, log line.

## B8. Scenario design
Net price: low (policy step down plus heavy contracting), base, high. Access: restrictive (step edits, exclusion), standard, favourable. Vary named drivers only. Show blended net price arithmetic and cumulative revenue difference.
Placeholder arithmetic (illustrative): channel shares 50% commercial, 35% Medicare, 15% Medicaid; net prices 100, 80, 60 index points: blended = 0.5 x 100 + 0.35 x 80 + 0.15 x 60 = 50 + 28 + 9 = 87. If Medicare net falls 25% from a negotiated price: Medicare 60; blended = 50 + 21 + 9 = 80; change = -7 points, or -8.0% of 87.

## B9. Checklist before sending
Gross or net stated; currency and price year; unit and channel; every deduction sourced or "not disclosed"; channel shares sum to 100%; policy status labelled (law, guidance, proposal, voluntary); dates verified; scenarios change named drivers; event probability has class and base rate or "base rate needed"; signposts dated; no invented rebate; draft label.

## B10. Common failures
List price used as net. One market's rebate applied to another. Policy rules asserted from memory. Mixing price per unit and per patient-year. Ignoring channel. Treating voluntary agreements as statute. Quoting a rebate with no source.
