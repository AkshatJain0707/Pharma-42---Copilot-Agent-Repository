# PLAYBOOK: Scenario Planning and Strategic Signposts
Standalone knowledge file. Version 1.0, built 20 October 2026 from sources read that day. Review every 90 days. Dated context items are VERIFY.

# PART A. CORE FORECASTING STANDARDS (built in, applies to every forecast)

## A1. Source tags and confidence
[P] primary: regulator document, registry, filing, statute, peer-reviewed paper. [S] secondary: trade press, analyst note, consultancy or law firm briefing. [U] unverified, user-supplied without source, or recalled. Confidence per conclusion: High (two or more independent primary sources agree), Medium (one primary, or primary plus consistent secondary), Low (secondary or unverified only, or sources conflict). Company press releases and investor decks are company-reported claims, not independent evidence.

## A2. A forecastable question
Event, date, resolution source. Weak: "Will the rival do well?" Strong: "Will the FDA approve X for indication Y by 30 June 2027, as shown on Drugs@FDA?" Rewrite vague questions and show the rewrite. No compound questions.

## A3. Base rate first, adjust in small named steps
Name the reference class. Find the base rate in a cited source (a retrieved or supplied source, or a dated figure in this playbook). State dataset, period, and definition of success. If none exists write "base rate needed". Adjust for case-specific evidence one named step at a time. Say how well the class fits and what differs. When two datasets disagree, show both and the effect on the answer.

## A4. Probability language
Give a range and a label, plus confidence in the basis. Labels: very unlikely under 10%, unlikely 10 to 30%, toss-up 30 to 70%, likely 70 to 90%, very likely over 90%. Never 0% or 100%. No false precision (no 37.4%). Probability (how likely) is separate from confidence (how good the evidence is).

## A5. Odds-form updating
odds = p / (1 - p). Posterior odds = prior odds x LR1 x LR2 x ... Posterior p = odds / (1 + odds). LR above 1 raises, below 1 lowers (use the reciprocal for opposing evidence). Judgement scale (a convention, not data): weak 1.5, moderate 2 to 3, strong 5, very strong 10. Count only independent evidence. Do not re-count what the reference class already reflects. If the posterior passes 95% or falls below 5%, widen the range. Arithmetic illustration only, not a base rate: prior 40% = odds 0.667; LR 2 = odds 1.333 = 57%.

## A6. Chains and combining
Chain probabilities (stage 1 x stage 2 x ...) only if stages are close to independent given the earlier stage; state the assumption. To combine several estimates of one event: convert to odds, take the (weighted) geometric mean, convert back, list the individual values, flag a spread above about 30 points, and explain the gap before relying on the aggregate.

## A7. Signposts, triggers, pre-mortem
Every forecast lists three to five signposts: an observable event, a source, whether it raises or lowers the estimate and how strongly, and a date or trigger. Add one decision trigger (if X by date, do Y). Run a pre-mortem: assume the forecast failed a year from now and list the three likeliest reasons and one cheap test.

## A8. Calibration
Log each forecast: ID, date, question, probability, resolution date. Brier score for a yes or no outcome = (p - outcome)^2; always saying 50% scores 0.25; lower is better. Under about 30 resolved forecasts, calibration statistics are indicative only. End every forecast with a one-line log entry.

## A9. Ethics and limits
Public information only. A probability about a listed company's event is an analytic judgement for strategy, not trading advice. No material non-public information. No coordination with competitors. No legal opinions. Follow competition law and the SCIP Code of Ethics.

## A10. Self-check before sending
Question resolvable? Base rate cited or "needed"? Every fact tagged? Range and label given? Signposts, trigger, pre-mortem, log line present? Any number from memory? Any horizon, currency, or unit mismatch? Anything that reads as advice or promotion? Fix before sending.

# PART B. DOMAIN KNOWLEDGE

## B1. Method references (concepts)
Scenario planning as used at Shell (Wack, Harvard Business Review, 1985): separate predetermined elements from true uncertainties, and change decision makers' mental models rather than predict. Schwartz, The Art of the Long View (1991): driving forces, critical uncertainties, scenario logics, implications, leading indicators. Reference class thinking (Kahneman and Lovallo; Flyvbjerg) to discipline estimates inside scenarios.

## B2. Steps in brief
1. Focal question and horizon. 2. Driving forces. 3. Rank by impact and predictability. 4. Choose scenario axes. 5. Write scenario logics. 6. Check consistency. 7. Implications and option stress test. 8. Leading indicators (signposts) and triggers. 9. Review cadence.

## B3. Pharma driver library
Clinical: readouts of competitors and own assets, safety signals, biomarker adoption, guideline inclusion. Regulatory: approval and label breadth, review clocks, complete response risk, accelerated approval confirmatory requirements, HTA outcomes. Access and price: negotiation programme outcomes, most-favored-nation agreements, Medicaid and Part D rules, payer channel decisions, private-label products, reference pricing, joint clinical assessment. Competitive: entry timing, price and contracting moves, deals, litigation. Supply: manufacturing and inspection capacity. Macro: currency, funding, trade policy.

## B4. Current context as of 20 Oct 2026 (secondary sources and agency documents read that day; VERIFY each)
Predetermined or scheduled (high confidence in timing, not in outcome):
- US Medicare negotiation: prices for cycle 1 effective 1 Jan 2026; cycle 2 prices effective 1 Jan 2027; cycle 3 (initial price applicability year 2028, 15 drugs including the first Part B drugs plus one renegotiation) negotiation period ends 31 Oct 2026, prices apply from 1 Jan 2028 (CMS guidance and KFF).
- FDA review clocks: standard 10 months and priority 6 months from the 60-day filing date for new molecular entity applications and original biologics; the next user fee agreement (PDUFA VIII) commitment letter covers 1 Oct 2027 to 30 Sep 2032 with the same cohort goals (FDA documents).
Uncertain, with live signals:
- EU pharmaceutical reform: Council adopted its first-reading position on 28 Sep 2026; European Parliament vote indicative for Nov 2026; baseline moves to 8 years data protection plus 1 year market protection with conditional extensions, capped at 11 years; full applicability expected around 2028 (legal summaries).
- Most-favored-nation pricing: 26 manufacturers announced agreements by 31 Aug 2026 (about 89% of the branded market per the White House); terms not public; extended to state Medicaid programs on 18 Sep 2026; voluntary, could change; a CMS proposed rule on Part B reported, status unverified.
- FDA transparency: complete response letters published on openFDA since Jul 2025, about 459 records by 13 Aug 2026; publication paused Apr 2026 and resumed 10 Jul 2026; rulemaking on release discretion targeted for Oct 2026 (secondary).
- Biosimilar uptake: step changes follow payer channel decisions; adalimumab biosimilar share 60% by Feb 2026 (including private label) after under 2% in year one; ustekinumab biosimilar share 27% Q4 2025 and 42% Q1 2026 (company-reported).
- Development success rates: Phase I to approval success fell to 6.7% in the 2014 to 2023 Citeline cohort from 7.9% in the BIO 2011 to 2020 report (different providers and periods).
Use these as driver evidence or predetermined elements; they are not forecasts.

## B5. Choosing axes
Pick uncertainties that are: high impact on the decision, low predictability, and weakly correlated. Name each axis as a spectrum with two poles (for example: payer channel decisions parity access to exclusion; competitor readout positive to negative). Four scenarios from two axes; avoid more than three axes. Reject axes that are only magnitude (high or low growth) unless the cause differs.

## B6. Consistency matrix
List the settings of each driver in rows and columns. Mark each pair: compatible, possible with tension, or incompatible. A scenario containing an incompatible pair is rewritten. Record the reason for each incompatible mark.

## B7. Stress test and scoring
Table: options in rows, scenarios in columns, payoff in cells (ordinal 1 to 5 or user numbers with units). Metrics: worst case (row minimum), regret (column best minus cell) and maximum regret, robustness score (count of scenarios where the cell meets the client's threshold). Classification: no-regret move (meets threshold in all scenarios), robust option (most), bet (one scenario; state which), hedge (cheap protection). Placeholder illustration: threshold 3; Option A scores 4, 2, 5, 3 across four scenarios: worst 2, robustness 3 of 4; Option B scores 3, 3, 3, 3: worst 3, robustness 4 of 4; B is the no-regret choice even though A has the highest single score.

## B8. Signposts: design rules
Specific, sourced, dated, and discriminating (they differ between scenarios). For each pair of neighbouring scenarios, give one signpost. Judgement likelihood ratio between scenarios: strong 5, moderate 2 to 3, weak 1.5 (a convention). Weak signposts fit every scenario. Examples: registry date changes, advisory committee scheduling, filing acceptance, payer policy publication, formulary announcements, guidance language shifts, litigation rulings, quarterly pipeline charts, policy rule publication.

## B9. Triggers and cadence
Pair key signposts with a pre-agreed action and owner role: "If X by date, move to option B." Keep to five triggers. Review monthly for fast-moving drivers and at each quarterly reporting cycle. Retire a scenario only when signposts rule it out.

## B10. Wildcards
Low-likelihood, high-impact events outside the driver set (for example a class safety warning, a policy shock, a manufacturing failure, a large merger). Do not build full scenarios. Note early signs and a contingency.

## B11. Worked example (illustrative placeholders)
Focal question: "How should Client C sequence its US launch of Asset A through 2029?" Axes: payer channel decisions (parity access to exclusion of competitors) and price policy (stable to tightening). Scenarios: S1 parity and stable, S2 exclusion deals and stable, S3 parity and tightening, S4 exclusion deals and tightening. Options: launch with contracting at day one, delay for more data, partner commercial rights. Signposts: payer formulary announcements, policy rule publications, competitor list-price moves. Triggers: if a major payer publishes exclusion criteria for the class by a named date, shift to contracting option. Each scenario must change an action: S2 and S4 change contracting stance; S3 and S4 change pricing and volume plans.

## B12. Checklist before sending
Focal question with decision and horizon; predetermined elements separated; two or three uncertainties; three or four scenarios, each changing a decision; consistency check; stress test with worst case, regret, robustness; discriminating signposts with dates; five triggers at most; wildcards; no probabilities unless asked; drivers sourced; pre-mortem; log line if probabilities given.

## B13. Common failures
Best, base, worst cases mistaken for scenarios. Scenarios differing only in size. More than four scenarios. No signposts. Drivers with no evidence. Treating a scenario as a forecast. Skipping the consistency check.
