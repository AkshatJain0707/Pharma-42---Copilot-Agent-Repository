# Standards and Submission Playbook

Version 1.0, built 20 October 2026. Review every 90 days. Dated versions and rules live in the separate "Volatile Standards Context" file, which is reviewed every 30 days. Items marked VERIFY change often and must be checked against the live source for the regulator in scope before they go into client work.

## 1. What a standards brief answers

A standards brief supports one planning or readiness decision. Write the question in one sentence first. Examples:

- "Which standards versions apply to our three studies for a US submission, and what is the bridging cost?"
- "Can we trace every analysis result to collected data, and where is the weakest link?"
- "What must be true before we send study data to the regulator?"

Weak plans pick the newest version, treat validation as the only gate, or leave derivations in programs only.

## 2. The standards landscape (names to know)

| Standard | Purpose |
|---|---|
| CDASH | Standard way to design data collection forms |
| SDTM and its implementation guides | Tabulation of study data for submission |
| SEND | Tabulation for nonclinical studies |
| ADaM | Analysis datasets for statistical analysis |
| Define-XML | Machine-readable dataset metadata |
| Controlled terminology | Standard term lists, updated regularly |
| Dataset-JSON | Newer exchange format being evaluated as an alternative to the legacy transport format |
| Analysis results and study definition standards | Emerging standards for results metadata and machine-readable study design (including the Unified Study Definitions Model) |
| Reviewer's guides | Documents explaining data and analysis choices to regulators |

Versions change often; see the Volatile file. Never state a current version from memory.

## 3. Standards Selection Record

Version selection is a row-level decision against the regulator's data standards catalogue, using the study start date, submission type, centre and data use. It is not a search for the newest version.

| Field | Content |
|---|---|
| Study and start date | Evidence for the date (protocol, first participant) |
| Regulator and centre | Where the submission goes |
| Catalogue row | The row and its support and requirement dates, from the live catalogue |
| Collection standard | Form standard and version |
| Tabulation model and guide | Versions |
| Analysis model and guide | Versions |
| Metadata | Define file version |
| Terminology | Release used |
| Transport format | As the technical conformance guide requires |
| Status | Verified, Not verified |

Keep one record per study. Do not declare a whole programme "on version X".

## 4. Traceability Chain

| Link | Needs | Common weakness |
|---|---|---|
| Collection forms to tabulation datasets | Mapping specification, annotated forms | Mapping only in code |
| Tabulation to analysis datasets | Derivation specification | Derivations undocumented |
| Analysis datasets to results | Program and output links | Results with no dataset reference |
| Metadata | Define file consistent with datasets | Define file generated late |
| Explanations | Reviewer's guides | Missing or generic |

A reviewer should follow any result back to a collected value. Test traceability with a sample of key results.

## 5. External data integration

For each vendor source: transfer specification, expected structure, mapping approach to the tabulation model, who converts, reconciliation, and how late changes are controlled. Decide early whether vendor data arrive close to the standard or need conversion. Include data transfer agreements and version control.

## 6. Bridging when versions differ

| Situation | Plan |
|---|---|
| Studies in one programme use different guide versions | List differences that affect pooled analyses and summaries; define a mapping layer or conversion; document the approach for reviewers |
| A new version is published mid-programme | Check the regulator catalogue by study start date; do not migrate studies already started without justification |
| Standards changes ripple to metadata and validation | Plan updates to define files, derivations, and validation settings |

Maintaining two mapping standards is a real cost; show it.

## 7. Submission Gate Table

| Gate | Check | Owner |
|---|---|---|
| Catalogue eligibility | Chosen versions fit the study start date and catalogue row | Regulatory and data standards lead |
| File and folder mechanics | Structure and naming match regulator requirements | Submission manager |
| Trial summary | Summary dataset consistent with the standards record | Programming lead |
| Automated validation | Rules run with the current rule set; each remaining issue explained | Programming lead |
| Regulator business rules | Rejection and business rules checked | Submission manager |
| Traceability and navigation | Sample trace tests passed; reviewer's guides complete | Statistics and programming leads |

Keep gates separate. Passing one does not imply the others.

## 8. Tooling note

Validation tools and rule engines exist (commercial and open source). Use the current rule set and the regulator's published rules; vendor claims are company-reported. Do not state that a tool guarantees acceptance.

## 9. Source order by question type

| Question | Sources, best first |
|---|---|
| Which versions does the regulator support? | The regulator's data standards catalogue and technical conformance guide |
| What does the standard say? | The standards body publications and implementation guides |
| What is changing? | Standards body news and public review notices; regulator Federal Register or equivalent notices |
| How do others cope? | Consultancy and trade articles as [S] |

## 10. Common failure modes

1. Choosing the newest version, not the one the catalogue allows for the start date.
2. One version declared for a whole programme.
3. Derivations only in code.
4. Define file produced at the last minute.
5. Vendor data conversion left to the end.
6. Treating validation as the only gate.
7. No sample traceability test.
8. Not tracking regulator catalogue updates.
9. Stating a requirement date from memory.
10. Leaving out what we do not know.

## 11. A short example brief

Request: "We have three studies starting in 2024 and 2025 for a US submission. Which standards apply?"

Bottom line. Version choice follows each study's start date and the regulator catalogue row, so studies starting before and after the catalogue date may need different guide versions. Plan a bridging layer for integrated summaries.

Standards Selection Record. One row per study with status "Not verified" until the catalogue row is checked.

Submission Gate Table. Catalogue eligibility, validation, and traceability are separate gates with owners.

Pre-mortem. This submission fails if the integrated summary relies on a mapping that was never documented for the older studies.
