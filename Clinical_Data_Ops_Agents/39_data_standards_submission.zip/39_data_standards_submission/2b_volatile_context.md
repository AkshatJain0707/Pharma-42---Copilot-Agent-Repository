# Volatile Standards Context

Built 20 October 2026. Review every 30 days. Each item shows its as-of date, source, tag and status. Always repeat the as-of date when you use an item, and say "verify current status for the regulator and study start date".

## US regulator standards

1. **Version selection.** Version choice is a row-level decision against the FDA Data Standards Catalog using study start date, submission type, centre, data use and format. A June 2026 edition of the Study Data Technical Conformance Guide makes the trial summary dataset the link between study start date and inbound validation. [S] Intuition Labs, 20 September 2026 (describing FDA documents). Verify with the FDA catalogue and guide.
2. **Tabulation guide.** Studies starting on or after 15 March 2025 are reported to follow SDTM Implementation Guide 3.4, a two-year gap after the previous mandate; SDTMIG 4.0 and ADaM 3.3.0 are reported as in the pipeline. Sponsors running studies under IG 3.3 alongside IG 3.4 maintain two mapping standards. [S] Certara, 26 August 2026. Verify with the FDA catalogue.
3. **Transport format.** As of a September 2026 summary, the FDA technical conformance guide still specified SAS Transport v5 (XPT) for study datasets. [S] Intuition Labs. In April 2025 FDA requested public comment on Dataset-JSON v1.1 as a possible long-term replacement; the transition is not finalised. [S] Clinical Leader, June 2026. Verify.
4. **Catalogue releases.** An earlier FDA Data Standards Catalog release (version 10.4) was dated September 2024. [S] Cytel. Check the current release.

## CDISC models and guides

5. **SDTM and ADaM versions.** SDTM model v3.0 and SDTMIG v4.0 were in public review in early 2026; ADaM Implementation Guide v1.3 dates from 2021, with ADaM v3.0 under development. [S] Intuition Labs, revised 5 April 2026; Clinical Leader. Verify the CDISC website.
6. **Dataset-JSON v1.1.** Reported released December 2024 by one source and December 2025 by another; verify the date with CDISC. [S] Cytel; Intuition Labs. A CDISC, PHUSE and FDA pilot (2023 to 2024) showed it can substitute for XPT in submissions. [S] Clinical Leader.
7. **Define-XML.** Version 2.1.8 reported December 2024. [S] Cytel. Verify the current version.
8. **Controlled terminology.** Terminology and conformance rules update roughly every six months, independent of major guide releases. [S] Certara. Always cite the release used.
9. **Study definition and protocol standards.** CDISC USDM v4.0 appears in 2026 guidance and ICH M11 (structured protocol template) is reported final in 2026. [S] Intuition Labs; GMP Compliance news. Verify.
10. **Open conformance rules engine.** CDISC CORE rule coverage is still expanding. [S] Clinical Leader.

## Other regulators

11. **EMA.** Clinical data standards submission requirements were long anticipated, with a pilot project; status not verified in this build. [S] Cytel, 2025. Verify.
12. **PMDA (Japan).** The Technical Conformance Guide on Electronic Study Data Submissions has been revised (2024 revision noted). [S] Cytel. Verify the current edition.

## Items to verify before use (no source in this build)

13. Current FDA Study Data Technical Conformance Guide version and any change to transport format requirements. [U]
14. Current FDA Data Standards Catalog row for each standard and study start date. [U]
15. Any new regulator requirement for standardised study data in India (CDSCO) or China (NMPA). [U]
