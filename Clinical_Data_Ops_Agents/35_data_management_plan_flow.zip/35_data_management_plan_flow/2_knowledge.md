# Data Management Playbook

Version 1.0, built 20 October 2026. Review every 90 days. Dated guidance lives in the separate "Volatile Clinical Data Rules Context" file, which is reviewed every 30 days. Items marked VERIFY change often and must be checked against the live source for the region in scope before they go into client work.

## 1. What a data management brief answers

A data management brief supports one planning decision. Write the question in one sentence first. Examples:

- "Which data streams are critical to the primary endpoint and what could make them unreliable?"
- "How should wearable data enter the study database without breaking blinding or reconciliation?"
- "What must be in place at each start-up gate before the first participant is enrolled?"

Weak plans list every data point as equally important, show vendors without oversight, or ignore how late or missing data will be handled.

## 2. Critical data and critical-to-quality factors

Modern good clinical practice (ICH E6(R3), see Volatile file) centres quality management on factors critical to quality: the elements that protect participants and keep the results reliable. For data operations, start from the trial's key decisions.

| Question | Typical critical data |
|---|---|
| What must be right for the primary conclusion? | Primary endpoint measurements, time of assessment, treatment assignment |
| What protects participants? | Eligibility, informed consent, serious adverse events, dose changes |
| What proves the right person got the right treatment? | Randomisation, drug supply and accountability |
| What would invalidate the data? | Missing key visits, unblinding, inconsistent time stamps |

Rule: if everything is critical, nothing is. Rank and justify. Link each critical item to a risk and a control.

## 3. Critical Data Register

| Data | Why critical | Risk | Control |
|---|---|---|---|
| Primary endpoint assessment | Decides efficacy | Missing, late or inconsistent assessments | Real-time completeness checks, central review of patterns |
| Serious adverse events | Participant safety, regulatory duty | Late or unreconciled reports | Timeliness tracking, reconciliation with safety database |
| Eligibility criteria | Population validity | Wrong participants enrolled | Source verification plan, central review |

## 4. Data Flow Map

| Source | Capture | Owner | Transfer | Reconciliation | Blinding impact |
|---|---|---|---|---|---|
| Electronic data capture | Site entry | Sponsor or vendor | Live database | Edit checks, queries | None |
| Central laboratory | Lab system | Lab vendor | Scheduled file | Match to visit dates and sample IDs | Possible if results reveal treatment |
| Electronic patient-reported outcomes | Participant device | eCOA vendor | Direct feed or file | Compliance and completion tracking | None |
| Imaging | Site upload to core lab | Imaging vendor | Reads file | Match scans to visits | Read blinded |
| Wearable or sensor | Device platform | Device vendor | API or file | Device ID, wear time | None, but check |
| Randomisation and supply | IRT | IRT vendor | Restricted | Restricted to unblinded staff | High |
| Electronic health record link | Site system | Site or vendor | Controlled extract | Source verification | Check |

For each row add frequency, format, and what happens if the transfer fails. Mark any single point of failure.

## 5. Source strategy options

| Choice | Option A | Option B | Gives up |
|---|---|---|---|
| Capture | Direct electronic capture at point of care | Paper then transcription | A: setup and site training. B: delay, transcription error |
| Endpoint measurement | Device-derived | Clinic-measured | A: validation and technology risk. B: burden and missing visits |
| Participant data | Remote or home collection | Site visits | A: data quality oversight. B: retention |

Always state what must be true (device validated for the endpoint, site capability, participant access).

## 6. Vendor Oversight Matrix

| Activity | Performed by | Sponsor oversight | Evidence | Escalation |
|---|---|---|---|---|
| Database build | Data management vendor | Review of specification and testing | Signed specifications, test evidence | Study lead |
| Central lab data transfer | Lab vendor | Transfer testing, reconciliation reviews | Transfer logs | Data manager |
| Coding | Coding team | Review of coding conventions and versions | Coding log | Medical lead |

Oversight cannot be delegated away. State who at the sponsor owns it.

## 7. Gate Plan

| Gate | Typical acceptance evidence | Sign-off |
|---|---|---|
| Case report form design freeze | Reviewed and approved form specifications mapped to protocol | Clinical lead, data manager, statistician |
| Database build and testing | Test scripts and results, defects closed | Data manager, quality |
| Go-live | System access, training records, user acceptance evidence | Study lead |
| First data transfers | Transfer specification, test files reconciled | Data manager, vendor lead |
| Ongoing | Change control log, audit trail review plan | Data manager |

Give durations as ranges with the assumption behind them.

## 8. Data Management Plan outline

Purpose and scope; study overview; roles and responsibilities; systems and validation status (stated by quality, not by this agent); data flow; case report form completion rules; edit checks and review listings; query handling; external data; coding; serious adverse event reconciliation; protocol deviation handling; blinded data review; database lock and archiving; training; change control; quality and risk management links; contingency plans.

## 9. Blinding safeguards

List who can see unblinded information (randomisation, drug supply, some lab or pharmacokinetic results), how it is restricted, and how the clean database avoids revealing treatment. Treat any unplanned unblinding as an incident for the study team and quality to manage.

## 10. Source order by question type

| Question | Sources, best first |
|---|---|
| What does GCP require? | ICH E6(R3) and regional adoption notices |
| What do regulators expect of computerised systems? | Regional guidance on computerised systems and electronic data |
| What do standards say? | CDISC and regulator data standards pages; see the Data Standards agent |
| What does the vendor offer? | Vendor documents (company-reported) |

## 11. Common failure modes

1. Everything labelled critical.
2. No owner for each data transfer.
3. External data reconciled at the end, not during the study.
4. Vendor oversight described as meetings only.
5. Wearable data with no validation of the endpoint.
6. Blinding broken by lab or pharmacokinetic transfers.
7. Plan written before the protocol is stable.
8. No plan for missing data.
9. Gate dates stated as facts.
10. Leaving out what we do not know.

## 12. A short example brief

Request: "Plan the data flow for a Phase 3 study using a wearable for the primary endpoint."

Bottom line. The primary endpoint depends on wearable data, so wear-time completeness and device validation are the critical risks. The data flow needs a reconciliation point between device and visit, and a rule for missing data agreed before first participant in.

Critical Data Register. Wearable endpoint: critical; risk: low wear time; control: daily completeness dashboard.

Data Flow Map. Device platform to database by application interface; reconciliation by device ID and visit.

Pre-mortem. This data plan fails if device validation for the endpoint is not accepted by the regulator.
