# Volatile Clinical Data Rules Context

Built 20 October 2026. Review every 30 days. Each item shows its as-of date, source, tag and status. Always repeat the as-of date when you use an item, and say "verify current status for the region in scope".

## ICH E6(R3) Good Clinical Practice

1. **Principles and Annex 1.** ICH Step 4 on 6 January 2025. EU, UK and Switzerland effective 23 July 2025. FDA published final E6(R3) guidance on 8 September 2025 (Federal Register notice 9 September 2025); like all FDA guidance, it is non-binding. [P/S] EMA and CHMP adoption table; CASRAI summary.
2. **Annex 2** (decentralised and pragmatic trials, real-world data sources, digital health technologies). ICH Step 4 on 3 June 2026; CHMP adoption 25 June 2026; effective in the EU 15 January 2027. A consolidated text combining Principles, Annex 1 and Annex 2 was published by EMA in July 2026. As of the sources checked, FDA had not issued a final Annex 2 guidance; one source describes an FDA draft published in December 2024. [P/S] EMA scientific guideline page; CASRAI; CRC Toolkit. Verify the FDA position.
3. **Content relevant to data operations.** Annex 1 adds a dedicated section on data governance for investigators and sponsors (including a subsection on safeguarding blinding in data governance), sets out quality management with quality tolerance limits as predefined acceptable ranges for critical trial metrics, and expects proportionate, risk-based oversight of vendors and computerised systems. [P/S] EMA E6(R3) Step 5 text, section headings; Intuition Labs summary of section 3.10.
4. **UK.** Revised UK clinical trial requirements are reported as implemented in April 2026, and MHRA released UK annotations to E6(R3) in January 2026. [S] DD Reg Pharma; CRC Toolkit. Verify with MHRA.

## Other rules to check

5. **FDA and EMA joint principles of good AI practice in drug development** were published 14 January 2026 and are non-binding. [S] NSF; Stephenson Harwood. If AI is used in data operations, hand governance to the AI Use Case and Governance Strategist.
6. **ICH M11 (structured protocol template)** is reported final in 2026 and supports machine-readable protocol content. [S, low confidence] Check ICH and regulators.
7. **India Digital Personal Data Protection Rules** notified 13 November 2025, phased commencement with main obligations from about 13 or 14 May 2027 (sources differ by a day). [S] Mondaq; AZB Partners; Nishith Desai. Affects data of participants in India.

## Items to verify before use (no source in this build)

8. Current EU guideline on computerised systems and electronic data in clinical trials and its effective date. [U]
9. Current FDA guidance on electronic systems, records and signatures in clinical investigations (Part 11 questions and answers). [U]
10. Current FDA guidance on decentralised elements in trials. [U]
11. Current CDSCO rules on electronic data, informed consent audio-visual recording and site obligations. [U]
