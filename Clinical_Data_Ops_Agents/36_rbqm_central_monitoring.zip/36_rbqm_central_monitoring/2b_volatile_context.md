# Volatile RBQM Rules Context

Built 20 October 2026. Review every 30 days. Each item shows its as-of date, source, tag and status. Always repeat the as-of date when you use an item, and say "verify current status for the region in scope".

## ICH E6(R3)

1. **Quality management and quality tolerance limits.** Annex 1 section 3.10 sets out risk-based quality management; section 3.10.1.3 on risk control introduces quality tolerance limits, described as predefined acceptable ranges for critical trial metrics that trigger action before data reporting. [S] Intuition Labs summary; the guideline text is in the EMA E6(R3) Step 5 document. Verify wording in the primary text.
2. **Effective dates.** Principles and Annex 1 effective in the EU 23 July 2025; FDA final guidance 8 September 2025 (non-binding). Annex 2 (decentralised, pragmatic and real-world data trials) ICH Step 4 on 3 June 2026 and effective in the EU 15 January 2027. [P/S] EMA; CASRAI. Verify FDA's Annex 2 position.
3. **Central versus on-site monitoring.** E6(R3) encourages proportionate, risk-based oversight and effective sponsor oversight of vendors, not simply evidence that routine meetings occurred. [S] DD Reg Pharma commentary. Verify against the guideline.

## Benchmarks (company-neutral, secondary)

4. **Site enrollment performance.** A Tufts CSDD analysis reported about 11 percent of ready-to-recruit sites enrolled no participants (13 percent in North America), and another summary of nearly 16,000 sites reported 48 percent of sites enrolled none or under-enrolled. A higher figure of 27 percent circulates in industry content and is not verified. [S] Applied Clinical Trials 2016; DataAlly 2026 summary. Use only as context; use the client's own site data for thresholds. Verify.
5. **Protocol amendments.** Protocols with at least one substantial amendment have been reported to run about three months longer on average. [S] Tufts CSDD via Applied Clinical Trials, 2016. Verify the current figure.

## Items to verify before use (no source in this build)

6. Current regulator guidance on risk-based monitoring (FDA, EMA, MHRA, CDSCO). [U]
7. Industry benchmark sets for KRIs and QTLs (for example consortium frameworks). [U] Do not quote thresholds from memory.
8. Any change in inspection focus areas for monitoring and oversight. [U]
