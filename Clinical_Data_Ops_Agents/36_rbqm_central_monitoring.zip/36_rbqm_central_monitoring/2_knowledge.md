# RBQM Playbook

Version 1.0, built 20 October 2026. Review every 90 days. Dated rules and benchmarks live in the separate "Volatile RBQM Rules Context" file, which is reviewed every 30 days. Items marked VERIFY change often and must be checked against the live source for the region in scope before they go into client work.

## 1. What an RBQM brief answers

An RBQM brief supports one quality oversight decision. Write the question in one sentence first. Examples:

- "Which indicators and limits should we use to protect the primary endpoint in this trial?"
- "A site shows unusually fast data entry and few adverse events. What should we check, and in what order?"
- "How do we scale oversight so high-risk sites get more attention without raising cost?"

Weak plans copy a generic indicator list, set thresholds from habit, or treat every deviation as equal.

## 2. Core ideas

| Term | Meaning |
|---|---|
| Critical-to-quality (CtQ) factor | An element of the trial whose failure could harm participants or make results unreliable |
| Quality tolerance limit (QTL) | A predefined acceptable range for a critical trial-level metric that triggers evaluation when crossed |
| Key risk indicator (KRI) | A measure of site, country or process behaviour that points to a risk |
| Risk assessment | Identifying, scoring and ranking risks to CtQ factors |
| Proportionate oversight | Effort matched to risk, using central review first and targeted action when indicators call for it |

State the distinction between QTLs (study level, linked to critical metrics) and KRIs (operational, often site level). Both need a basis and an action.

## 3. CtQ-to-KRI Ladder

| CtQ factor | Risk | Indicator | Data source | Threshold and basis | Action | Owner |
|---|---|---|---|---|---|---|
| Primary endpoint data complete | Missing or late assessments | Share of expected assessments missing | EDC | Proposed range from protocol and history; for sign-off | Contact site, review cause | Data manager |
| Eligibility correct | Ineligible participants | Rate of eligibility queries or deviations | EDC, deviation log | Peer comparison | Site retraining, central review | Study lead |
| Safety reporting timely | Late reporting | Days from event to report | Safety database, EDC | Protocol and regulatory timelines (VERIFY) | Escalate to medical monitor | PV lead |
| Consent properly obtained | Missing or late consent | Consent date versus first procedure | EDC, site records | Zero tolerance for missing consent | Quality assurance review | QA |
| Randomisation and treatment correct | Wrong treatment | Dosing errors | IRT, EDC | Zero tolerance | Immediate review | Study lead |

Common KRIs: screen failure rate, enrollment rate, query rate and age, data entry delay, protocol deviation rate by type, missed visits, dropout rate, adverse event reporting rate relative to peers, serious adverse event reporting delay, out-of-window visits, duplicate or inconsistent values, laboratory data patterns, device compliance.

Rules: thresholds are hypotheses; show the basis; get study team and statistician sign-off; review them when data show they are wrong.

## 4. Signal Triage Card

| Field | Content |
|---|---|
| Signal | What the data shows, with numbers, period and comparison group |
| Competing explanations | At least two: for example data entry practice, protocol misunderstanding, different population, reporting culture, true quality issue |
| Evidence for and against each | From data and context |
| Check that separates them | A targeted data review, a call to the site, review of source documents |
| Do not conclude yet | What the data cannot show |
| Escalation | To whom, by when |

Statistical monitoring patterns (for example digit preference, very low variability, duplicate values, unusual correlations) are prompts for review. They are never findings on their own.

## 5. Site Risk View (components)

| Component | Example measure |
|---|---|
| Enrollment | Participants screened and randomised versus plan |
| Data timeliness | Days to enter data, query response time |
| Data quality | Query rate, missing key data |
| Protocol adherence | Important deviations per participant |
| Safety reporting | Timeliness and rate versus peers |
| Retention | Dropout and missed visits |

Do not combine into a single score without showing the parts. Use the components to choose the action: central review only, remote contact, targeted on-site visit, retraining, or watch.

## 6. Proportionate Oversight Plan

| Element | Guidance |
|---|---|
| Central review | Scheduled indicator review, with cadence set by trial phase and risk |
| Triggers | Defined crossing of limits or a signal that stays unexplained |
| Remote actions | Calls, targeted data reviews, retraining |
| On-site actions | For unresolved high-risk signals or critical issues |
| Documentation | Each decision, its reason and outcome |
| Review of the plan | At set intervals and after changes or amendments |

## 7. Quality metrics reporting

Dashboards should show: indicator, value, threshold, trend, and action status. Show comparisons only in blinded form. Keep the story short for the study team.

## 8. Vendor oversight

Quality management covers vendors: define the metrics the vendor reports, how the sponsor checks them, and what happens if they are missed. Oversight evidence goes beyond meeting minutes.

## 9. Source order by question type

| Question | Sources, best first |
|---|---|
| What does GCP expect? | ICH E6(R3) and regional adoption notices |
| What do regulators say about monitoring? | Regulator guidance on risk-based monitoring and quality management |
| What are typical values? | Own historical data first; then published benchmarks, tagged [S] |

## 10. Common failure modes

1. A generic KRI list with no link to critical factors.
2. Thresholds from habit with no basis.
3. Treating a signal as a finding.
4. One risk score for sites.
5. Unblinded comparisons in monitoring reports.
6. No action defined for a crossed limit.
7. Ignoring vendors.
8. Never revising thresholds.
9. Safety signals handled as data quality signals.
10. Leaving out what we do not know.

## 11. A short example brief

Request: "A site enters data within one hour of visits and reports no adverse events. What do we do?"

Bottom line. This pattern is unusual compared with peers but has several ordinary explanations. Check peer comparison, visit schedule and source documents before concluding anything.

Signal Triage. Explanations: (1) site uses real-time entry and few events occurred in a low-risk population; (2) adverse events are under-reported or entered late; (3) data are entered by someone other than the investigator. Check: compare event rates by peer sites with similar enrollment; targeted source review of recent visits.

Do not conclude yet. This is not evidence of misconduct. Escalate through the study's quality procedure if the check cannot explain it.

Pre-mortem. This quality plan fails if the adverse event reporting indicator has no peer baseline.
