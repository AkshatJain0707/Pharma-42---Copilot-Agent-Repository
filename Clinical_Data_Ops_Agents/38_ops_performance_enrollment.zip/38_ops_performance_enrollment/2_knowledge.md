# Operations Analytics Playbook

Version 1.0, built 20 October 2026. Review every 90 days. Dated benchmarks and rules live in the separate "Volatile Operations Benchmarks Context" file, which is reviewed every 30 days. Items marked VERIFY change often and must be checked against the live source for the region in scope before they go into client work.

## 1. What an operations analytics brief answers

An operations brief supports one scheduling or resourcing decision. Write the question in one sentence first. Examples:

- "When will we complete enrollment, and how sure are we?"
- "Should we add ten sites or amend the eligibility criteria?"
- "Which sites should we support, watch or close?"

Weak briefs give one date, assume every activated site enrols, or treat benchmarks as the forecast.

## 2. Enrollment funnel

| Stage | Question | Typical leak |
|---|---|---|
| Sites selected | How many were chosen? | Wrong sites |
| Sites activated | How many are open to enrol? | Contract and ethics delays |
| Sites screening | How many actually screen? | Sites activated but idle |
| Participants screened | How many were assessed? | Referral flow |
| Screen failures | How many do not qualify? | Eligibility restrictiveness |
| Randomised or enrolled | How many started? | Consent decisions, logistics |
| Completed | How many finish? | Dropout, burden |

Show plan versus actual at each stage. The biggest leak decides the best action.

## 3. Enrollment forecast method (conceptual)

Participants enrolled by a date depend on: number of active sites over time, per-site enrollment rate (which varies widely), screen failure, and dropout. A simple approach:

1. Model site activation over time (planned and actual).
2. Take per-site rates from the client's history in similar trials and indications; show the spread, not only the mean.
3. Combine into a cumulative enrollment curve for Low, Base and High scenarios.
4. Adjust for seasonality and holidays where relevant.
5. Update as actual data arrive; more actuals narrow the range.

Many teams use statistical models in which site rates vary by site (for example Poisson with a gamma distributed rate) to produce prediction intervals. Describe this at concept level and say a statistician builds and validates the model. Always report ranges and the sensitivity to the two biggest drivers.

## 4. Site performance scorecard (components)

| Component | Measure |
|---|---|
| Activation | Days from selection to activation |
| Enrollment | Participants versus plan, time to first participant |
| Screen failure | Share of screened not eligible |
| Retention | Dropout and missed visits |
| Data timeliness | Days to data entry, query response |
| Protocol adherence | Important deviations per participant |
| Workload | Concurrent studies, staff turnover |

Classify: Support (potential but constrained), Watch (mixed), Replace (persistent non-performance after support). The study team decides. Do not combine into a single ranking without showing parts.

## 5. Protocol complexity check

| Factor | Effect |
|---|---|
| Restrictive eligibility | Lower enrollment, higher screen failure |
| Visit burden and procedures | Lower retention, site workload |
| Complex assessments | More deviations and queries |
| Many amendments | Longer timelines; amendments are associated with longer study duration |
| Rare population | Fewer patients per site, need global network |

Name the single protocol feature most likely to slow enrollment. Any change is a clinical and statistical decision following the amendment process.

## 6. Recovery options

| Option | Typical effect | Time to effect | Watch-outs |
|---|---|---|---|
| Add sites in current countries | More enrollment, new activation time | Months | Idle sites; overlap with competing trials |
| Add countries | New patient pools | Longer (regulatory, ethics) | Standard-of-care differences |
| Widen eligibility (amendment) | Fewer screen failures | Months | Scientific and statistical review, regulatory and ethics approvals |
| Simplify visits or add remote elements | Better retention and access | Months | Data quality oversight |
| Referral networks and patient outreach | More referrals | Weeks to months | Rules on outreach materials |
| Retention support | Fewer dropouts | Weeks | Cost, compliance |

Give each effect as a range with the basis. Show cost direction and risk.

## 7. Critical path to key milestones

List the steps and who owns them: site activation, first participant in, enrollment completion, last participant last visit, data cleaning, database lock. Show which step has the longest uncertainty and which delays cascade. Use ranges, not dates.

## 8. Operational KPI design

| KPI | Reading |
|---|---|
| Activation cycle time | Start-up health |
| Share of activated sites enrolling | Site selection quality |
| Screen failure rate | Eligibility fit |
| Enrollment versus plan | Schedule |
| Dropout rate | Retention |
| Query age and rate | Data effort |
| Milestone variance | Planning accuracy |

Report trends, comparisons to plan, and actions, not just counts.

## 9. Source order by question type

| Question | Sources, best first |
|---|---|
| How did our past trials perform? | The client's own trial history |
| What do regulators or ICH say? | ICH E6(R3) and regional documents |
| What are industry benchmarks? | Peer-reviewed and independent research centres; see Volatile file for sponsor and age |
| Who competes for patients? | Trial registries (see Pipeline and Trial Watch Analyst) |

## 10. Common failure modes

1. A single enrollment date.
2. Counting activated sites as enrolling sites.
3. Benchmarks used as forecasts.
4. One performance score per site.
5. Lowering eligibility to hit a number.
6. Ignoring amendments' effect on timelines.
7. Adding sites in the same crowded region.
8. Naming investigators as poor performers from data alone.
9. No update rule for the forecast.
10. Leaving out what we do not know.

## 11. A short example brief

Request: "We are 40 percent enrolled at the planned halfway point. What do we do?"

Bottom line. At current per-site rates the last participant in lands in a range of 8 to 14 months later than plan. The biggest leak is that a third of activated sites have not enrolled anyone. Fixing site support will help more than adding sites in the same regions.

Funnel. Sites activated 60; sites with at least one participant 38.

Forecast. Low, Base and High with the two biggest drivers: per-site rate and screen failure rate.

Recovery options. Support idle sites; add two countries with lower competition; review eligibility with the clinical and statistical team.

Pre-mortem. This timeline fails if the idle sites cannot be activated or replaced within three months.
