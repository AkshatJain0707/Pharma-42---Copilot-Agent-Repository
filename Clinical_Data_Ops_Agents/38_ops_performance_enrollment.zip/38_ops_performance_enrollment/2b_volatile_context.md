# Volatile Operations Benchmarks Context

Built 20 October 2026. Review every 30 days. Each item shows its as-of date, source, tag and status. Benchmarks are context only. Always repeat the as-of date and the source type when you use an item, and say "verify current status".

## Benchmarks (secondary; context only)

1. **Sites that never enrol.** A Tufts CSDD analysis (reported 2012) found about 11 percent of ready-to-recruit sites enrolled no participants, 13 percent in North America. A summary of nearly 16,000 sites reported 48 percent of selected sites either enrolled nobody or under-enrolled. A higher figure of 27 percent circulates in industry content and is not verified. [S] Applied Clinical Trials 2016; DataAlly summary, July 2026. Use only to frame the question; use the client's own site data.
2. **Enrollment timelines.** One 2020 review of enrollment barriers is cited for more than 80 percent of trials not meeting their original enrollment timeline. [S] DataAlly summary, July 2026. Verify the primary source.
3. **Protocol amendments.** Protocols with at least one substantial amendment have been reported to run about three months longer on average. [S] Tufts CSDD via Applied Clinical Trials, 2016.
4. **Cost of delay.** A Tufts CSDD 2024 analysis is cited for Phase III trial conduct cost of about 55,716 USD per day. [S] DataAlly summary, July 2026. Verify the primary source and the cost definition.
5. **Site start-up.** Early site initiation steps (pre-study visit to contract execution) account for most cycle time and variance; sites in Latin America took about twice as long as North America to first participant in an older analysis. [S] Tufts CSDD via Applied Clinical Trials 2016. Verify with a current benchmark.
6. **Direct-to-patient site analysis.** A vendor-sponsored analysis with Tufts CSDD (2026) compares one vendor's direct-to-patient site with benchmarks from 857 traditional sites, reporting higher enrollment per site and shorter cycle times. [Company-reported, S] Science 37 press release 19 May 2026; Applied Clinical Trials commentary 8 May 2026. Treat as company-reported; do not use as an industry norm.

## Regulatory context

7. **ICH E6(R3) Annex 2** covers decentralised and pragmatic trial elements and trials using real-world data; ICH Step 4 on 3 June 2026; effective in the EU 15 January 2027. FDA's position on Annex 2 was not final in sources checked. [P/S] EMA; CASRAI. Verify before designing decentralised elements.
8. **UK** revised clinical trial requirements reported implemented April 2026. [S] DD Reg Pharma. Verify with MHRA.
9. **India** clinical trial rules and ethics timelines are set by CDSCO and local ethics committees. [U] Verify current timelines.

## Items to verify before use (no source in this build)

10. Current industry benchmarks for site activation, screen failure and dropout by therapeutic area. [U] Use licensed benchmark sets or the client's history.
11. Current country-level start-up timelines (regulatory, ethics, contract). [U]
12. Any change in rules on participant recruitment materials and outreach. [U]
