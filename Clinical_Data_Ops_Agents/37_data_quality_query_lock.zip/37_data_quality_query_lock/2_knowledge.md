# Data Quality and Lock Playbook

Version 1.0, built 20 October 2026. Review every 90 days. Dated rules live in the separate "Volatile Data Quality Rules Context" file, which is reviewed every 30 days. Items marked VERIFY change often and must be checked against the live source for the region in scope before they go into client work.

## 1. What a data quality brief answers

A data quality brief supports one decision about cleaning effort or lock timing. Write the question in one sentence first. Examples:

- "Which query categories can we remove with better edit checks, to cut the open query count before lock?"
- "Is the database on track for lock in six weeks, and what is the biggest blocker?"
- "Why do three sites account for most queries, and what should we do?"

Weak analyses count queries without asking what they protect, chase every discrepancy with the same effort, or declare readiness on a single measure.

## 2. Data quality dimensions

| Dimension | Question | Example evidence |
|---|---|---|
| Completeness | Is the data that should exist present? | Missing key assessments, blank mandatory fields |
| Accuracy | Does it reflect what happened? | Source verification findings, outliers confirmed |
| Consistency | Do related values agree? | Dates out of order, units mixed |
| Plausibility | Are values believable? | Out-of-range values, impossible combinations |
| Timeliness | Was it entered and reviewed on time? | Days from visit to entry |
| Traceability | Can each value be traced to source and changes? | Audit trail complete, change reasons |

Rank by the importance of the affected data. A missing primary endpoint outweighs a missing optional comment.

## 3. Query Analytics Lens

| Metric | What it shows | Reading rule |
|---|---|---|
| Queries per participant or form | Burden and design problems | High on a form suggests unclear form or edit check issue |
| Median age and ageing tail | Responsiveness | Long tail points to site capacity or unclear questions |
| Reopen rate | Query clarity | High means the first query was unclear or the answer unsatisfactory |
| Share of queries that changed data | Value of queries | Low means many queries add noise |
| Category and reason | Root cause | Group into entry error, unclear form, protocol issue, system check issue |
| Site and form hot spots | Where to act | Retrain, simplify, or change the check |

Replace queries with: automatic checks at entry, central review listings, or training, where the cause is systematic.

## 4. Query hygiene

| Do | Avoid |
|---|---|
| Ask for clarification or confirmation | Suggesting the answer (leading) |
| Cite the form, field, and the discrepancy | Vague queries |
| Close with a documented reason | Silent data changes |
| Keep neutral wording | Pressure or blame |

All corrections follow documented procedures with an audit trail and an authorised person. Never advise otherwise.

## 5. Edit Check Strategy

| Check type | Use for | Example |
|---|---|---|
| Automated at entry | Critical data, clear rules | Required endpoint field, date logic |
| Review listing | Patterns needing judgement | Concomitant medication versus adverse event timing |
| Risk-based monitoring | Signals at site level | Unusual variability, see RBQM agent |
| No check | Low value data, high noise | Free text with no analysis use |

Every check has a cost (query volume, site burden). Justify each against the critical data it protects.

## 6. Reconciliation Tracker

| Data source | Match key | Frequency | Owner | Discrepancy types | Closure criteria |
|---|---|---|---|---|---|
| Serious adverse events (clinical and safety databases) | Participant and event identifiers, dates | Per safety review cycle | Data manager and pharmacovigilance | Missing, different dates or terms | All discrepancies resolved or explained |
| Central laboratory | Sample ID, visit, dates | Per transfer | Data manager | Missing results, unit differences | Matched or documented |
| Pharmacokinetic and other external data | Sample and visit keys | Per transfer | Data manager, clinical pharmacology | Time and dose mismatches | Matched or documented |
| Coding (adverse events, medications, history) | Dictionary and version | Periodic | Coding specialist, medical reviewer | Inconsistent coding, version differences | Coding reviewed and approved |
| Randomisation and supply (restricted) | Restricted | Per policy | Unblinded team only | Not available to blinded analysts | Per study procedure |

Keep blinded and unblinded work apart.

## 7. Database Lock Readiness Scorecard

| Item | Typical evidence | Status |
|---|---|---|
| Data entry complete for all expected visits and forms | Missing page report | Ready, At risk, Blocked |
| Queries resolved or closed with reason | Query report | |
| Serious adverse event reconciliation complete | Reconciliation log | |
| External data final and reconciled | Transfer and reconciliation records | |
| Coding complete and reviewed | Coding report | |
| Protocol deviations classified | Deviation log | |
| Blinded data review done | Review minutes | |
| Audit trail review done as planned | Audit trail review record | |
| Database and system access closed as planned | Access report | |
| Sign-offs ready | Sign-off checklist | |

Rules: show each status with owner and evidence. The decision to lock is the study team's, with the statistician and quality. After lock, any change follows a documented post-lock change control process.

## 8. Medical coding review points

Check: dictionary and version used; consistent coding of the same term; unusual terms; verbatim to coded mapping; medical review of coding choices; version change handling during the study. Coding versions update on a regular schedule; check the live dictionary version (see Volatile file). Do not state a coded term for an actual participant event.

## 9. Source order by question type

| Question | Sources, best first |
|---|---|
| What does GCP expect for data governance? | ICH E6(R3) and regional adoption notices |
| What are the regulator data integrity expectations? | Regulator guidance on data integrity and electronic records |
| What is the status of the study? | Study metrics from the study systems (aggregated) |

## 10. Common failure modes

1. Counting queries without root cause.
2. Querying every discrepancy with the same priority.
3. Leading queries.
4. Late external data reconciliation.
5. Reconciliation done with unblinded data by blinded staff.
6. Declaring lock readiness on one measure.
7. Unplanned post-lock changes.
8. Changing coding versions late with no review.
9. No audit trail review plan.
10. Leaving out what we do not know.

## 11. A short example brief

Request: "We have 4,000 open queries four weeks before planned lock. What should we do?"

Bottom line. The query count alone does not show readiness. Group queries by cause and by critical data, close the ones protecting the primary endpoint and safety first, and replace the systematic ones with checks and training.

Query Analytics. Median age and ageing tail, reopen rate, and share that changed data show where effort is wasted.

Lock Readiness. Serious adverse event reconciliation: At risk. External laboratory data: Blocked until final transfer.

Pre-mortem. This lock fails if the final external data transfer arrives after the planned cut-off.
