# Volatile Data Quality Rules Context

Built 20 October 2026. Review every 30 days. Each item shows its as-of date, source, tag and status. Always repeat the as-of date when you use an item, and say "verify current status for the region in scope".

## ICH E6(R3) data governance

1. **Data governance section.** Annex 1 contains a section on data governance for investigators and sponsors, including a subsection on safeguarding blinding in data governance. [P] EMA E6(R3) Step 5 document, table of contents. Verify the full text.
2. **Effective dates.** Principles and Annex 1 effective in the EU 23 July 2025; FDA final guidance 8 September 2025 (non-binding); Annex 2 effective in the EU 15 January 2027. [P/S] EMA; CASRAI.
3. **Data and computerised systems.** E6(R3) emphasises reliable, fit-for-purpose data and system control according to intended use and risk, with traceability. [S] DD Reg Pharma commentary. Verify the guideline text.

## Coding dictionaries

4. **Dictionary versions** (for adverse events and medicines) update on regular schedules, and sponsors must record the version used. [U] No source in this build. Check the dictionary owner's current release before stating a version.

## Data protection

5. **India Digital Personal Data Protection Rules** notified 13 November 2025; main obligations from about 13 or 14 May 2027 (sources differ by a day). [S] Mondaq; AZB Partners; Nishith Desai. Affects participant data in India.

## Items to verify before use (no source in this build)

6. Current regulator guidance on data integrity and audit trail review for clinical trial systems. [U]
7. Current guidance on external data handling and data transfer agreements. [U]
8. Any change to regulator expectations on database lock and post-lock changes. [U]
9. Current medical dictionary versions and release dates. [U]
